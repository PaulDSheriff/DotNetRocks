using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.IO;
using System.Security.Permissions;
using System.Web.Profile;
using System.Xml;

/// <summary>
/// Summary description for XmlProfileProvider
/// </summary>
public class XmlProfileProvider : ProfileProvider
{
	private string mAppName = string.Empty;
	private string mFileName = string.Empty;

	public override void Initialize(string name,
		 NameValueCollection config)
	{
		// Store application name
		mAppName = name;

		// Get File Name from Path attribute in Web.Config
		mFileName = HttpContext.Current.Server.MapPath(GetFromConfig(config, "fileName"));
		if (mFileName.Trim() == String.Empty)
		{
			throw new System.Configuration.ConfigurationErrorsException("'fileName' attribute in your Web.Config file must be set to a valid path and file name");
		}

		// Call the base class's Initialize method
		base.Initialize(name, config);


		// Check for appropriate File Permissions
		FileIOPermission permission =
			 new FileIOPermission(FileIOPermissionAccess.AllAccess,
										  HttpContext.Current.Server.MapPath(
										  "~/XML"));
		permission.Demand();
	}

	public override string ApplicationName
	{
		get { return mAppName; }
		set { mAppName = value; }
	}

	public override SettingsPropertyValueCollection
		 GetPropertyValues(SettingsContext context,
		 SettingsPropertyCollection collection)
	{
		XmlNode node;
		XmlNode childNode;
		SettingsPropertyValueCollection spvc = new SettingsPropertyValueCollection();
		SettingsPropertyValue spv;
		XmlDocument xd;

		// Retrieve the Profile XML Document
		xd = GetXmlDocument();
		if (xd != null)
		{
			// Find the user in the XML File
			node = GetUserNode(xd, context["UserName"].ToString());

			foreach (SettingsProperty sp in collection)
			{
				spv = new SettingsPropertyValue(sp);

				// See if we can find the node in the Profile.xml file
				childNode = node.SelectSingleNode(sp.Name);
				if (childNode != null)
				{
					spv.Property.PropertyType = sp.PropertyType;
					spv.PropertyValue =
					 Convert.ChangeType(childNode.InnerText, sp.PropertyType);
				}

				spvc.Add(spv);
			}
		}

		return spvc;
	}

	public override void SetPropertyValues(SettingsContext context,
		 SettingsPropertyValueCollection collection)
	{
		XmlNode node;
		XmlNode propertyNode;
		XmlDocument xd;

		xd = GetXmlDocument();
		if (xd != null)
		{
			node = GetUserNode(xd, context["UserName"].ToString());
			if (node == null)
			{
				// Create new XmlNode
			}
			else
			{
				// Write to XML file here
				foreach (SettingsPropertyValue spv in collection)
				{
					propertyNode = node.SelectSingleNode(spv.Property.Name);
					if (propertyNode == null)
					{
						// Create the node
						propertyNode = node.OwnerDocument.CreateElement(spv.Property.Name);
						node.AppendChild(propertyNode);
					}
					propertyNode.InnerText = spv.PropertyValue.ToString();
				}
			}
			xd.Save(mFileName);
		}
	}

	#region "Private Methods"
	private XmlNode GetUserNode(XmlDocument xd, string UserName)
	{
		return xd.SelectSingleNode(String.Format("Profiles/Profile[(@userName='{0}')]", UserName));
	}

	private string GetFromConfig(NameValueCollection config, string KeyName)
	{
		string strReturn = string.Empty;

		if (config != null)
		{
			if (!string.IsNullOrEmpty(config[KeyName]))
			{
				strReturn = config[KeyName];
			}
		}

		return strReturn;
	}

	private XmlDocument GetXmlDocument()
	{
		XmlDocument xd = new XmlDocument();

		try
		{
			xd.Load(mFileName);

			// Add caching code here later
		}
		catch (Exception)
		{

			throw new FileNotFoundException("Your XML File: " + mFileName + " does not exist!");
		}

		return xd;
	}

	#endregion

	#region "Methods not yet implemented"
	public override int DeleteInactiveProfiles
		 (ProfileAuthenticationOption authenticationOption,
		 DateTime userInactiveSinceDate)
	{
		throw new NotSupportedException();
	}

	public override int DeleteProfiles(string[] usernames)
	{
		throw new NotSupportedException();
	}

	public override int DeleteProfiles(ProfileInfoCollection profiles)
	{
		throw new NotSupportedException();
	}

	public override ProfileInfoCollection
		 FindInactiveProfilesByUserName(ProfileAuthenticationOption
		 authenticationOption, string usernameToMatch, DateTime
		 userInactiveSinceDate, int pageIndex, int pageSize, out int
		 totalRecords)
	{
		throw new NotSupportedException();
	}

	public override ProfileInfoCollection FindProfilesByUserName
		 (ProfileAuthenticationOption authenticationOption,
		 string usernameToMatch, int pageIndex, int pageSize,
		  out int totalRecords)
	{
		throw new NotSupportedException();
	}

	public override ProfileInfoCollection GetAllInactiveProfiles
		 (ProfileAuthenticationOption authenticationOption,
		 DateTime userInactiveSinceDate, int pageIndex, int pageSize,
		  out int totalRecords)
	{
		throw new NotSupportedException();
	}

	public override ProfileInfoCollection GetAllProfiles
		 (ProfileAuthenticationOption authenticationOption,
		 int pageIndex, int pageSize, out int totalRecords)
	{
		throw new NotSupportedException();
	}

	public override int GetNumberOfInactiveProfiles
		 (ProfileAuthenticationOption authenticationOption,
		 DateTime userInactiveSinceDate)
	{
		throw new NotSupportedException();
	}
	#endregion
}
