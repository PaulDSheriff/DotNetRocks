using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ShowAllRoles : System.Web.UI.Page
{

	private const int COL_ROLE_NAME = 1;

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			DisplayRoles();
			ddlUser.DataTextField = "Username";
			ddlUser.DataSource = Membership.GetAllUsers();

			ddlUserAdd.DataTextField = "UserName";
			ddlUserAdd.DataSource = Membership.GetAllUsers();

			ddlUserDelete.DataTextField = "UserName";
			ddlUserDelete.DataSource = Membership.GetAllUsers();

			ddlUser.DataBind();
			ddlUserAdd.DataBind();
			ddlUserDelete.DataBind();

			BindRoleLists();
		}

		lblResults.Text = string.Empty;
		lblStatus.Text = string.Empty;

		btnDeleteUserFromRole.Enabled = (ddlRoleDelete.Items.Count > 0);
	}

	private void BindRoleLists()
	{
		ddlRoleAdd.DataSource = Roles.GetAllRoles();
		ddlRole.DataSource = Roles.GetAllRoles();

		if (ddlUserDelete.SelectedItem != null)
		{
			ddlRoleDelete.DataSource = Roles.GetRolesForUser(ddlUserDelete.SelectedItem.Text);
		}
		else
		{
			ddlRoleDelete.DataSource = Roles.GetAllRoles();
		}

		ddlRoleAdd.DataBind();
		ddlRole.DataBind();
		ddlRoleDelete.DataBind();
	}

	private void DisplayRoles()
	{
		grdRoles.DataSource = Roles.GetAllRoles();
		grdRoles.DataBind();
	}

	private void DisplayRolesForDelete(string strUser)
	{
		ddlRoleDelete.DataSource = Roles.GetRolesForUser(strUser);
		ddlRoleDelete.DataBind();
		btnDeleteUserFromRole.Enabled = (ddlRoleDelete.Items.Count > 0);
	}

	protected void btnAdd_Click(object sender, EventArgs e)
	{
		try
		{
			Roles.CreateRole(txtRole.Text);

			ddlRoleAdd.DataSource = Roles.GetAllRoles();
			ddlRoleAdd.DataBind();

			ddlRole.DataSource = Roles.GetAllRoles();
			ddlRole.DataBind();

			txtRole.Text = string.Empty;
			DisplayRoles();
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}

	protected void btnAddUserToRole_Click(object sender, EventArgs e)
	{
		string strUser;

		try
		{
			strUser = ddlUserAdd.SelectedItem.Text;

			Roles.AddUserToRole(strUser, ddlRoleAdd.SelectedItem.Text);

			DisplayRolesForDelete(strUser);
			DisplayRoles();
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}

	protected void btnCheckUserInRole_Click(object sender, EventArgs e)
	{
		bool boolRet;
			
		boolRet = Roles.IsUserInRole(ddlUser.SelectedItem.Text, ddlRole.SelectedItem.Text);

		lblResults.Text = boolRet.ToString();
	}

	protected void btnDeleteUserFromRole_Click(object sender, EventArgs e)
	{
		string strUser;

		try
		{
			strUser = ddlUserDelete.SelectedItem.Text;

			if (ddlRoleDelete.SelectedItem != null)
			{
				Roles.RemoveUserFromRole(strUser, ddlRoleDelete.SelectedItem.Text);

				DisplayRolesForDelete(strUser);
				DisplayRoles();
			}
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}

	protected void grdRoles_RowCreated(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			string strRole = Roles.GetAllRoles()[e.Row.RowIndex];
			e.Row.Cells[1].Text = strRole;
			e.Row.Cells[2].Text = string.Join(", ", Roles.GetUsersInRole(strRole));
		}
	}

	protected void grdRoles_RowDeleting(object sender, GridViewDeleteEventArgs e)
	{
		string strRole;

		try
		{
			strRole = grdRoles.Rows[e.RowIndex].Cells[COL_ROLE_NAME].Text;

			Roles.DeleteRole(strRole, true);

			DisplayRoles();
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}
	protected void ddlUserDelete_SelectedIndexChanged(object sender, EventArgs e)
	{
		DisplayRolesForDelete(ddlUserDelete.SelectedItem.Text);
	}
}
