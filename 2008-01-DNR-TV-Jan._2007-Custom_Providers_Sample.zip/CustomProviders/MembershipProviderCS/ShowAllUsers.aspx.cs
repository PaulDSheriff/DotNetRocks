using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ShowAllUsers : System.Web.UI.Page
{

	private const int USERNAME_COL = 8;

	protected void Page_Load(object sender, EventArgs e)
	{
		DisplayUsers();

		lblStatus.Text = string.Empty;

	}

	private void DisplayUsers()
	{
		grdUsers.Caption = "All Users";
		grdUsers.DataSource = Membership.GetAllUsers();
		grdUsers.DataBind();
	}

	private void ClearControls()
	{
		txtEmail.Text = string.Empty;
		txtUserName.Text = string.Empty;
		txtPassword.Text = string.Empty;
		txtPasswordQuestion.Text = string.Empty;
		txtPasswordAnswer.Text = string.Empty;

		txtNewPassword.Text = string.Empty;
		txtNewPasswordQuestion.Text = string.Empty;
		txtNewPasswordAnswer.Text = string.Empty;
		txtOldPassword.Text = string.Empty;
	}
	protected void btnFindUsersByEmail_Click(object sender, EventArgs e)
	{
		grdUsers.Caption = "Find Users by Email (" + txtFindByEmail.Text + ")";
		grdUsers.DataSource = Membership.FindUsersByEmail(txtFindByEmail.Text);
		grdUsers.DataBind();
	}
	protected void btnFindUsersByName_Click(object sender, EventArgs e)
	{
		grdUsers.Caption = "Find Users by Name (" + txtFindByName.Text + ")";
		grdUsers.DataSource = Membership.FindUsersByName(txtFindByName.Text);
		grdUsers.DataBind();
	}

	protected void btnShowAll_Click(object sender, EventArgs e)
	{
		DisplayUsers();
	}

	protected void btnAdd_Click(object sender, EventArgs e)
	{
		MembershipCreateStatus status;

		try
		{
			Membership.CreateUser(txtUserName.Text,
			 txtPassword.Text, txtEmail.Text,
			 txtPasswordQuestion.Text, txtPasswordAnswer.Text,
			 true, out status);
			lblStatus.Text = "Status = " + status.ToString();

			ClearControls();
			DisplayUsers();
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}

	protected void btnChangePassword_Click(object sender, EventArgs e)
	{
		MembershipUser user;

		user = Membership.GetUser(txtSelectedUserName.Text);
		if (user != null)
		{
			if (user.ChangePassword(txtOldPassword.Text, txtNewPassword.Text))
			{
				if (user.ChangePasswordQuestionAndAnswer(
				 txtNewPassword.Text, txtNewPasswordQuestion.Text,
				 txtNewPasswordAnswer.Text))
				{
					lblStatus.Text = "Success!";
				}
				else
				{
					lblStatus.Text = "Unable to change password question/answer.";
				}
			}
			else
			{
				lblStatus.Text = "Unable to change the password.";
			}
		}

		DisplayUsers();
	}

	protected void btnResetPassword_Click(object sender, EventArgs e)
	{
		MembershipUser user;

		try
		{
			user = Membership.GetUser(txtSelectedUserName.Text);

			lblStatus.Text = "New password = " + user.ResetPassword(txtPasswordAnswer.Text);
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}

	protected void grdUsers_RowDeleting(object sender, GridViewDeleteEventArgs e)
	{
		string strUser;

		try
		{
			strUser = grdUsers.Rows[e.RowIndex].Cells[USERNAME_COL].Text;

			Membership.DeleteUser(strUser);

			DisplayUsers();
		}
		catch (Exception ex)
		{
			lblStatus.Text = ex.Message;
		}
	}
	protected void grdUsers_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
	{
		string strUser;

		strUser = grdUsers.Rows[e.NewSelectedIndex].Cells[USERNAME_COL].Text;

		pnlPassword.Visible = true;

		txtSelectedUserName.Text = strUser;
	}
}
