using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Xml;
using System.Collections.Specialized;

public class XmlRoleProvider : RoleProvider
{
	private string mAppName;
	private string mProviderName;
	private string mFileName;
	private NameValueCollection mConfig;

	public override void Initialize(string name, NameValueCollection config)
	{
		base.Initialize(name, config);

		try
		{
			mProviderName = name;
			mConfig = config;

			mFileName = HttpContext.Current.Server.MapPath(GetFromConfig("dataFile"));
			if (mFileName == string.Empty)
			{
				throw new ConfigurationErrorsException("'dataFile' attribute in web.config must be set to a valid file name.");
			}
		}
		catch (Exception ex)
		{
			throw new ConfigurationErrorsException(string.Format("Could not read the configuration settings from {0}.", mFileName), ex);
		}
	}

	#region "Overridden Properties"
	public override string ApplicationName
	{
		get
		{
			return mAppName;
		}
		set
		{
			mAppName = value;
		}
	}

	#endregion

	#region "Methods Implemented"
	public override void AddUsersToRoles(string[] usernames, string[] roleNames)
	{
		XmlDocument xd;
		XmlNode nodeRole;
		XmlNode nodeUser;

		try
		{
			xd = GetXmlDocument();

			foreach (string roleName in roleNames)
			{
				nodeRole = xd.SelectSingleNode(string.Format(@"//Role[@roleName='{0}']", roleName));
				if (nodeRole != null)
				{
					foreach (string userName in usernames)
					{
						nodeUser = nodeRole.SelectSingleNode(string.Format(@"User[@userName='{0}']", userName));
						if (nodeUser == null)
						{
							InsertTextElement(nodeRole, "User", "", "userName", userName);
						}
						else
						{
							throw new HttpException(string.Format("User '{0}' is already in role '{1}'.", userName, roleName));
						}
					}
				}
			}

			xd.Save(mFileName);
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to add users to roles.", ex);
		}
	}

	public override void CreateRole(string roleName)
	{
		XmlDocument xd;
		XmlElement elem;
		XmlNode node;

		xd = GetXmlDocument();
		elem = xd.DocumentElement;
		node = xd.SelectSingleNode(string.Format(@"//Role[@roleName='{0}']", roleName));

		if (node == null)
		{
			InsertTextElement(elem, "Role", "", "roleName", roleName);
			xd.Save(mFileName);
		}
		else
		{
			throw new HttpException(String.Format("Role '{0}' already exists.", roleName));
		}
	}

	public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
	{
		bool boolRet = false;
		XmlDocument xd;
		XmlNode node;
		try
		{
			xd = GetXmlDocument();
			node = xd.SelectSingleNode(string.Format(@"//Role[@roleName='{0}']", roleName));
			if (node == null)
			{
				throw new HttpException(string.Format("Role '{0}' was not found.", roleName));
			}
			else
			{
				if (throwOnPopulatedRole && node.HasChildNodes)
				{
					throw new HttpException("Unable to delete role because it contains users.");
				}
				else
				{
					node.ParentNode.RemoveChild(node);
					xd.Save(mFileName);
				}
			}
			boolRet = true;
		}
		catch (HttpException ex)
		{
			throw ex;
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to delete role.", ex);
		}

		return boolRet;
	}

	public override string[] GetAllRoles()
	{
		string[] astrRet;
		XmlDocument xd;
		XmlNodeList nodeList;
		int intLoop = 0;

		try
		{
			xd = GetXmlDocument();
			nodeList = xd.SelectNodes(@"//Role");
			astrRet = new string[nodeList.Count];

			foreach (XmlNode node in nodeList)
			{
				astrRet[intLoop] = node.Attributes.GetNamedItem("roleName").Value;
				intLoop++;
			}
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to retrieve roles.", ex);
		}

		return astrRet;
	}

	public override string[] GetRolesForUser(string username)
	{
		string[] astrRet;
		XmlDocument xd;
		XmlNodeList nodeList;
		int intLoop = 0;

		try
		{
			xd = GetXmlDocument();
			nodeList = xd.SelectNodes(string.Format(@"//User[@userName='{0}']", username));
			astrRet = new string[nodeList.Count];

			foreach (XmlNode node in nodeList)
			{
				astrRet[intLoop] = node.ParentNode.Attributes.GetNamedItem("roleName").Value;
				intLoop++;
			}
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to retrieve roles for user.", ex);
		}

		return astrRet;
	}

	public override string[] GetUsersInRole(string roleName)
	{
		string[] astrRet;
		XmlDocument xd;
		XmlNodeList nodeList;
		int intLoop = 0;

		try
		{
			xd = GetXmlDocument();
			nodeList = xd.SelectNodes(string.Format(@"//Role[@roleName='{0}']/User", roleName));
			astrRet = new string[nodeList.Count];

			foreach (XmlNode node in nodeList)
			{
				astrRet[intLoop] = node.Attributes.GetNamedItem("userName").Value;
				intLoop++;
			}
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to retrieve users for this role.", ex);
		}

		return astrRet;
	}

	public override bool IsUserInRole(string username, string roleName)
	{
		XmlDocument xd;
		XmlNode node = null;

		try
		{
			xd = GetXmlDocument();
			node = xd.SelectSingleNode(string.Format(@"//Role[@roleName='{0}']/User[@userName='{1}']", roleName, username));
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to determine if user is in role.", ex);
		}

		return (node != null);
	}

	public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
	{
		XmlDocument xd;
		XmlNode node;

		try
		{
			xd = GetXmlDocument();

			foreach (string roleName in roleNames)
			{
				foreach (string userName in usernames)
				{
					node = xd.SelectSingleNode(string.Format(@"//Role[@roleName='{0}']/User[@userName='{1}']", roleName, userName));
					if (node != null)
						node.ParentNode.RemoveChild(node);
				}
			}
			xd.Save(mFileName);
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to remove users from roles.", ex);
		}
	}

	public override bool RoleExists(string roleName)
	{
		XmlDocument xd;
		XmlNode node = null;

		try
		{
			xd = GetXmlDocument();
			node = xd.SelectSingleNode(string.Format(@"//Role[@roleName='{0}']", roleName));
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException(string.Format("Unable to determine if role '{0}' exists.", roleName), ex);
		}

		return (node != null);
	}
	#endregion

	#region "Methods still to be implemented"
	public override string[] FindUsersInRole(string roleName, string usernameToMatch)
	{
		return null;
	}
	#endregion

	#region "Private Methods"
	private string GetFromConfig(string keyName)
	{
		string strRet = string.Empty;

		if (mConfig != null)
		{
			if (mConfig[keyName] != null)
			{
				strRet = mConfig[keyName].ToString();
			}
		}

		return strRet;
	}

	private XmlDocument GetXmlDocument()
	{
		XmlDocument xd = new XmlDocument();

		try
		{
			xd.Load(mFileName);
			// you could cache the object here

		}
		catch (Exception ex)
		{

			throw new System.IO.FileNotFoundException("The XML file" + mFileName + " does not exist.", ex);
		}

		return xd;
	}

	private XmlElement InsertTextElement(XmlNode node, string tagName, string Text)
	{
		return InsertTextElement(node, tagName, Text, string.Empty, string.Empty);
	}

	private XmlElement InsertTextElement(XmlNode node, string tagName, string Text, string AttributeName, string AttributeValue)
	{
		XmlElement elem;
		XmlDocument xd = node.OwnerDocument;

		elem = xd.CreateElement(tagName);
		elem.AppendChild(xd.CreateTextNode(Text));
		node.AppendChild(elem);
		if (AttributeName != string.Empty)
			elem.SetAttribute(AttributeName, AttributeValue);

		return elem;
	}

	#endregion

}
