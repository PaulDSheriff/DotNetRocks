using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Xml;
using System.Collections.Specialized;


/// <summary>
/// Summary description for XmlMembershipProvider
/// </summary>
public class XmlMembershipProvider : MembershipProvider
{
	private const int PWD_NON_NUMERIC_CHARS = 0;
	private const int PWD_MIN_LENGTH = 5;
	private const int PWD_MAX_LENGTH = 10;
	private const int PWD_MAX_ATTEMPTS = 4;
	private const int PWD_ATTEMPT_WINDOW = 3;

	private string mProviderName;
	private string mFileName;
	private NameValueCollection mConfig;

	public override void Initialize(string name, NameValueCollection config)
	{
		base.Initialize(name, config);

		try
		{
			mProviderName = name;
			mConfig = config;

			mFileName = HttpContext.Current.Server.MapPath(GetFromConfig("dataFile"));
			if (mFileName == string.Empty)
			{
				throw new ConfigurationErrorsException("'dataFile' attribute in web.config must be set to a valid file name.");
			}
		}
		catch (Exception ex)
		{
			throw new ConfigurationErrorsException(string.Format("Could not read the configuration settings from {0}.", mFileName), ex);
		}
	}

	#region "Overridden Properties"
	public override string ApplicationName
	{
		get
		{
			return GetFromConfig("appName");
		}
		set
		{
			throw new InvalidOperationException("Can't set the ApplicationName property");
		}
	}

	public override string Name
	{
		get
		{
			return mProviderName;
		}
	}

	public override bool EnablePasswordReset
	{
		get { return true; }
	}

	public override bool EnablePasswordRetrieval
	{
		get { return true; }
	}

	public override int MaxInvalidPasswordAttempts
	{
		get { return PWD_MAX_ATTEMPTS; }
	}

	public override int MinRequiredNonAlphanumericCharacters
	{
		get { return PWD_NON_NUMERIC_CHARS; }
	}

	public override int MinRequiredPasswordLength
	{
		get { return PWD_MIN_LENGTH; }
	}

	public override int PasswordAttemptWindow
	{
		get { return PWD_ATTEMPT_WINDOW; }
	}

	public override MembershipPasswordFormat PasswordFormat
	{
		get { return MembershipPasswordFormat.Hashed; }
	}

	public override string PasswordStrengthRegularExpression
	{
		get { throw new Exception("The method or operation is not implemented."); }
	}

	public override bool RequiresQuestionAndAnswer
	{
		get { return false; }
	}

	public override bool RequiresUniqueEmail
	{
		get { return true; }
	}

	#endregion

	#region "Methods Implemented"
	public override bool ChangePassword(string username, string oldPassword, string newPassword)
	{
		bool boolRet = false;
		XmlDocument xd;
		XmlNode node;

		try
		{
			xd = GetXmlDocument();
			node = GetUserElement(xd, username, oldPassword);

			if (node != null)
			{
				((XmlElement)node).SetAttribute("password", newPassword);
				xd.Save(mFileName);
				boolRet = true;
			}
		}
		catch (Exception ex)
		{
			throw new MembershipPasswordException("Unable to change the password.", ex);
		}

		return boolRet;
	}

	public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
	{
		MembershipUser user = null;
		XmlDocument xd;
		XmlNode node;
		XmlElement xmlUser;

		status = MembershipCreateStatus.Success;
		try
		{
			xd = GetXmlDocument();

			// Check to make sure the user doesn't already exist
			node = xd.SelectSingleNode(string.Format(@"//User[@userName='{0}']", username));
			if (node != null)
			{
				status = MembershipCreateStatus.DuplicateUserName;
			}
			else
			{
				xmlUser = xd.CreateElement("User");
				xd.DocumentElement.AppendChild(xmlUser);

				xmlUser.SetAttribute("userName", username);
				xmlUser.SetAttribute("password", password);
				xmlUser.SetAttribute("email", email);
				xmlUser.SetAttribute("passwordQuestion", passwordQuestion);
				xmlUser.SetAttribute("passwordAnswer", passwordAnswer);
				xmlUser.SetAttribute("isApproved", isApproved.ToString());
				user = GetUserInfo(xmlUser);
				xd.Save(mFileName);
			}
		}
		catch
		{
			// Don't throw any errors. Simply return an error.
			status = MembershipCreateStatus.ProviderError;
		}

		return user;
	}

	public override bool DeleteUser(string username, bool deleteAllRelatedData)
	{
		bool boolRet = true;
		XmlDocument xd;
		XmlNode node;

		try
		{
			xd = GetXmlDocument();

			// Check to make sure the user exists.
			node = xd.SelectSingleNode(string.Format(@"//User[@userName='{0}']", username));
			if (node != null)
			{
				node.ParentNode.RemoveChild(node);
				xd.Save(mFileName);
			}
		}
		catch
		{
			boolRet = false;
		}

		return boolRet;
	}

	public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
	{
		MembershipUserCollection muc = new MembershipUserCollection();
		XmlDocument xd;

		xd = GetXmlDocument();
		if (xd != null)
		{
			foreach (XmlNode node in xd.SelectNodes("//User"))
			{
				// do a case insensitive search
				if (node.Attributes["email"].Value.ToLower() == emailToMatch.ToLower())
				{
					muc.Add(GetUserInfo((XmlElement)node));
				}
			}
		}
		totalRecords = muc.Count;

		return muc;
	}

	public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
	{
		MembershipUserCollection muc = new MembershipUserCollection();
		XmlDocument xd;

		xd = GetXmlDocument();
		if (xd != null)
		{
			foreach (XmlNode node in xd.SelectNodes("//User"))
			{
				// do a case insensitive search
				if (node.Attributes["userName"].Value.ToLower() == usernameToMatch.ToLower())
				{
					muc.Add(GetUserInfo((XmlElement)node));
				}
			}
		}
		totalRecords = muc.Count;

		return muc;
	}

	public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
	{
		MembershipUserCollection muc;

		muc = BuildUserCollection();

		totalRecords = muc.Count;

		return muc;
	}

	public override MembershipUser GetUser(string username, bool userIsOnline)
	{
		return GetUserByName(username);
	}

	public override string GetUserNameByEmail(string email)
	{
		string strRet = string.Empty;
		XmlDocument xd;
		XmlNode node;

		try
		{
			xd = GetXmlDocument();

			// Find the user
			node = xd.SelectSingleNode(string.Format(@"//User[@email='{0}']", email));
			if (node != null)
			{
				strRet = node.Attributes["userName"].Value;
			}
		}
		catch (Exception ex)
		{
			throw new InvalidOperationException("Unable to find user name by email.", ex);
		}

		return strRet;
	}

	public override string ResetPassword(string username, string answer)
	{
		string strRet = string.Empty;

		if (this.EnablePasswordReset)
		{
			strRet = Membership.GeneratePassword(PWD_MAX_LENGTH, PWD_NON_NUMERIC_CHARS);
		}

		return strRet;
	}

	public override void UpdateUser(MembershipUser user)
	{
		XmlDocument xd;
		XmlNode node;

		xd = GetXmlDocument();
		node = xd.SelectSingleNode(string.Format(@"//User[@userName='{0}']", user.UserName));
		if (node != null)
			SetUserInfo(user, node);

		xd.Save(mFileName);
	}

	public override bool ValidateUser(string username, string password)
	{
		bool boolRet = false;
		XmlDocument xd;
		XmlElement xmlUser;

		// Check to see if user exists
		xd = GetXmlDocument();
		if (xd != null)
		{
			xmlUser = GetUserElement(xd, username, password);
			boolRet = (xmlUser != null);
		}

		return boolRet;
	}
	#endregion

	#region "Methods still to be Implemented"

	public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
	{
		return true;
	}

	public override int GetNumberOfUsersOnline()
	{
		throw new Exception("The method or operation is not implemented.");
	}

	public override string GetPassword(string username, string answer)
	{
		throw new Exception("The method or operation is not implemented.");
	}

	public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
	{
		throw new Exception("The method or operation is not implemented.");
	}

	public override bool UnlockUser(string userName)
	{
		throw new Exception("The method or operation is not implemented.");
	}
	#endregion

	#region "Private Methods"
	private string GetFromConfig(string keyName)
	{
		string strRet = string.Empty;

		if (mConfig != null)
		{
			if (mConfig[keyName] != null)
			{
				strRet = mConfig[keyName].ToString();
			}
		}

		return strRet;
	}

	private XmlDocument GetXmlDocument()
	{
		XmlDocument xd = new XmlDocument();

		try
		{
			xd.Load(mFileName);
			// you could cache the object here

		}
		catch (Exception ex)
		{

			throw new System.IO.FileNotFoundException("The XML file" + mFileName + " does not exist.", ex);
		}

		return xd;
	}

	private MembershipUser GetUserByName(string userName)
	{
		XmlDocument xd;
		XmlNode node = null;

		xd = GetXmlDocument();
		node = xd.SelectSingleNode(string.Format(@"//User[(@userName='{0}')]", userName));

		return GetUserInfo((XmlElement)node);
	}

	private XmlElement GetUserElement(XmlDocument xd, string userName, string password)
	{
		XmlNode node = null;

		// Given a user name and a password, retrieve the correct user from 
		// the XML document. Note that XML is case-sensitive for both 
		// username and password!
		// Throw all exceptions back to the caller.
		node = xd.SelectSingleNode(
		 string.Format(@"//User[(@userName='{0}') and (@password='{1}')]", 
		 userName, password));

		return (XmlElement)node;
	}

	private XmlElement GetUserElementByEmail(XmlDocument xd, string email)
	{
		XmlNode node = null;

		// Given an email address, retrieve the correct user from 
		// the XML document. Note that XML is case-sensitive for both 
		// username and password!
		// Throw all exceptions back to the caller.
		node = xd.SelectSingleNode(string.Format(@"//User[(@email='{0}')]", email));

		return (XmlElement)node;
	}

	private MembershipUserCollection BuildUserCollection()
	{
		MembershipUserCollection muc = new MembershipUserCollection();
		XmlDocument xd;

		xd = GetXmlDocument();
		if (xd != null)
		{
			foreach (XmlNode node in xd.SelectNodes("//User"))
			{
				muc.Add(GetUserInfo((XmlElement)node));
			}
		}

		return muc;
	}

	private MembershipUser GetUserInfo(XmlElement elem)
	{
		MembershipUser user = new MembershipUser(mProviderName,
		 elem.GetAttribute("userName"),
		 elem.GetAttribute("userName"),
		 elem.GetAttribute("email"),
		 elem.GetAttribute("passwordQuestion"),
		 elem.GetAttribute("passwordAnswer"),
		 Convert.ToBoolean(elem.GetAttribute("isApproved")),
		 false, DateTime.Today, DateTime.Today, DateTime.Today, DateTime.Today, DateTime.Today);

		return user;
	}

	private XmlNode SetUserInfo(MembershipUser user, XmlNode node)
	{
		XmlElement elem;

		elem = (XmlElement)node;
		elem.Attributes["userName"].Value = user.UserName;
		elem.Attributes["email"].Value = user.Email;
		elem.Attributes["passwordQuestion"].Value = user.PasswordQuestion;
		elem.Attributes["isApproved"].Value = user.IsApproved.ToString();

		return elem;
	}

	#endregion


}
