Public Class TestClass1
  Implements ITest

  Public Sub InformUser() Implements ITest.InformUser
    MessageBox.Show("Hello from TestClass1")
  End Sub
End Class
