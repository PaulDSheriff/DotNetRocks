Public Class TestClass2
  Implements ITest

  Public Sub InformUser() Implements ITest.InformUser
    MessageBox.Show("Hello from TestClass2")
  End Sub
End Class
