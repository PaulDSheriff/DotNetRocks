Public Interface ITest
  Sub InformUser()
End Interface