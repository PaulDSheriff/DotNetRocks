Public Class frmInterface

  Private Sub btnTest1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest1.Click
    Test1()
  End Sub

  Private Sub Test1()
    Dim it As ITest

    it = New TestClass1()

    it.InformUser()
  End Sub

  Private Sub btnTest2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest2.Click
    Test2()
  End Sub

  Private Sub Test2()
    Dim it As ITest

    it = New TestClass2()

    it.InformUser()
  End Sub
End Class