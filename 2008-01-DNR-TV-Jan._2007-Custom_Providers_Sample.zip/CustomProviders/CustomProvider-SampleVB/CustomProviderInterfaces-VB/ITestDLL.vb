Public Interface ITestDLL
  Sub InformUser()
End Interface
