Public Class frmActivator

  Private Sub btnTest1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest1.Click
    CreateClass("CustomProvider_SampleVB.TestClass1")
  End Sub

  Private Sub btnTest2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest2.Click
    CreateClass("CustomProvider_SampleVB.TestClass2")
  End Sub

  Private Sub CreateClass(ByVal ClassName As String)
    Dim it As ITest
    Dim typ As System.Type

    typ = Type.GetType(ClassName)
    it = CType(System.Activator.CreateInstance(typ), ITest)

    it.InformUser()
  End Sub
End Class