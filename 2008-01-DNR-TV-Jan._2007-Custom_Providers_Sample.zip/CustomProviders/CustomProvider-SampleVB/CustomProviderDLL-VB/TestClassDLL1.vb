Imports System.Windows.Forms
Imports CustomProviderInterfaces_VB

Public Class TestClassDLL1
  Implements ITestDLL

  Public Sub InformUser() Implements ITestDLL.InformUser
    MessageBox.Show("Hello from CustomProviderDLL_VB.TestClassDLL1")
  End Sub
End Class
