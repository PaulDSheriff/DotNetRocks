Imports System.Windows.Forms
Imports CustomProviderInterfaces_VB

Public Class TestClassDLL2
  Implements ITestDLL

  Public Sub InformUser() Implements ITestDLL.InformUser
    MessageBox.Show("Hello from CustomProviderDLL_VB.TestClassDLL2")
  End Sub
End Class
