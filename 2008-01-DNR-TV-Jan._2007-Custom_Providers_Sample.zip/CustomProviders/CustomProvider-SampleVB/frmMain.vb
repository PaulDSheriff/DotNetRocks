Public Class frmMain

  Private Sub btnInterface_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInterface.Click
    Dim frm As New frmInterface

    frm.Show()
  End Sub

  Private Sub btnLoadAssm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadAssm.Click
    Dim frm As New frmAssmLoad()

    frm.Show()
  End Sub

  Private Sub btnActivator_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnActivator.Click
    Dim frm As New frmActivator()

    frm.Show()
  End Sub
End Class
