Imports CustomProviderInterfaces_VB

Public Class frmAssmLoad
  Private Const ASSMFILENAME As String = "D:\Samples\CustomProvider-SampleVB\CustomProviderDLL-VB\bin\Debug\CustomProviderDLL-VB.dll"
  Private Const ASSMNAME As String = "CustomProviderDLL-VB"

  Private Sub frmAssmLoad_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    txtAssmName.Text = "D:\MyStuff\Conference-Sessions\DotNet2.0\CustomProviders\Samples\CustomProvider-SampleVB\CustomProviderDLL-VB\bin\Debug\CustomProviderDLL-VB.dll"
    txtClassName.Text = "CustomProviderDLL_VB.TestClassDLL1"
  End Sub

  Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
    CreateClass(txtAssmName.Text, txtClassName.Text)
  End Sub

  Private Sub CreateClass(ByVal AssmName As String, ByVal ClassName As String)
    Dim assm As System.Reflection.Assembly
    Dim it As ITestDLL

    Try
      ' Use Load if the assembly is in the GAC 
      ' or in the Current Directory
      'assm = System.Reflection.Assembly.Load(AssmName)

      ' Use LoadFile if assembly is on file system, 
      ' NOT in GAC and not in the Current Directory
      assm = System.Reflection.Assembly.LoadFile(AssmName)

      ' Create new instance of Class
      it = CType(assm.CreateInstance(ClassName), ITestDLL)

      it.InformUser()

    Catch ex As Exception
      MessageBox.Show(ex.Message)

    End Try
  End Sub
End Class