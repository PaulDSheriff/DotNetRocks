using System;
using System.Configuration;

namespace DataProviderSampleCS
{
	public class AppConfig
	{
		public static string ConnectString
		{
			get
			{
				string ProviderName;

				// Get Provider Name
				ProviderName = ConfigurationManager.AppSettings["ProviderName"];

				// Get Connect String
				return ConfigurationManager.ConnectionStrings[ProviderName].ConnectionString;
			}
		}
	}
}
