CREATE TABLE tblProducts
(
	iProduct_id int NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY,
	sProductName varchar (50) NOT NULL ,
	dtIntroduced datetime NULL ,
	cCost money NULL ,
	cPrice money NULL ,
	bDiscontinued tinyint NULL
)
