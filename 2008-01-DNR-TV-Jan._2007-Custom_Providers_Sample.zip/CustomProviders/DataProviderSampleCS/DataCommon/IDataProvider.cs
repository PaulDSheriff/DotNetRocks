using System;
using System.Data;

namespace DataCommon
{
	interface IDataProvider
	{
		IDbConnection CreateConnection();
		IDbCommand CreateCommand();
		IDbDataAdapter CreateDataAdapter();
	}
}
