using System;
using System.Configuration;
using System.Data;

namespace DataCommon
{
	public class DataLayer
	{
		public static void ResetProvider()
		{
			DataProvider = null;
		}

		#region "Data Retrieval Methods"
		public static DataSet GetDataSet(string SQL, string ConnectString)
		{
			DataSet ds = new DataSet();
			IDbDataAdapter da;

			da = CreateDataAdapter(SQL, ConnectString);

			da.Fill(ds);

			return ds;
		}
		#endregion

		#region "Create Connection/Command/Parameter/DataAdapter Objects"

		private static IDataProvider DataProvider = null;

		private static void InitProvider()
		{
			string TypeName;
			string ProviderName;

			if(DataProvider == null)
			{
				// Get Provider Name
				ProviderName = ConfigurationManager.AppSettings["ProviderName"];
				// Get Type to Create
				TypeName = ConfigurationManager.AppSettings[ProviderName];
				// Create new DataProvider
				DataProvider = (IDataProvider) Activator.CreateInstance(Type.GetType(TypeName));
			}
		}

		public static IDbConnection CreateConnection(string ConnectString)
		{
			IDbConnection cnn;

			// Make Sure Provider is Created
			InitProvider();

			cnn = DataProvider.CreateConnection();
			cnn.ConnectionString = ConnectString;

			return cnn;
		}

		public static IDbCommand CreateCommand(string SQL)
		{
			IDbCommand cmd;

			// Make Sure Provider is Created
			InitProvider();

			cmd = DataProvider.CreateCommand();

			cmd.CommandText = SQL;

			return cmd;
		}

		public static IDbCommand CreateCommand(string SQL, string ConnectString)
		{
			return CreateCommand(SQL, ConnectString, true);
		}

		public static IDbCommand CreateCommand(string SQL, string ConnectString, bool OpenConnection)
		{
			IDbCommand cmd;

			// Make Sure Provider is Created
			InitProvider();

			cmd = CreateCommand(SQL);

			cmd.Connection = CreateConnection(ConnectString);
			if (OpenConnection)
			{
				cmd.Connection.Open();
			}

			return cmd;
		}

		public static IDbDataAdapter CreateDataAdapter(string SQL, string ConnectString)
		{
			IDbDataAdapter da;

			// Make Sure Provider is Created
			InitProvider();
			
			da = DataProvider.CreateDataAdapter();

			da.SelectCommand = CreateCommand(SQL, ConnectString, false);

			return da;
		}

		#endregion
	}
}
