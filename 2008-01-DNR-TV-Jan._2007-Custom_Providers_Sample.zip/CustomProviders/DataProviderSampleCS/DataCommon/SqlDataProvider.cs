using System;
using System.Data;
using System.Data.SqlClient;

namespace DataCommon
{
	class SqlDataProvider : IDataProvider
	{
		#region "SQL Server Specific Methods"
		// The following methods only handle SQL Server
		public IDbConnection CreateConnection()
		{
			SqlConnection cnn = new SqlConnection();

			return cnn;
		}

		public IDbCommand CreateCommand()
		{
			SqlCommand cmd = new SqlCommand();

			return cmd;
		}

		public IDbDataAdapter CreateDataAdapter()
		{
			SqlDataAdapter da = new SqlDataAdapter();

			return da;
		}
		#endregion
	}
}
