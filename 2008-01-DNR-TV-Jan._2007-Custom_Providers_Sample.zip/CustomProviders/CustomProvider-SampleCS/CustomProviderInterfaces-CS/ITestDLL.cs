using System;
using System.Collections.Generic;
using System.Text;

namespace CustomProviderInterfaces_CS
{
  public interface ITestDLL
  {
    void InformUser();
  }
}
