using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CustomProvider_SampleCS
{
  public partial class frmInterface : Form
  {
    public frmInterface()
    {
      InitializeComponent();
    }

    private void btnTest1_Click(object sender, EventArgs e)
    {
      Test1();
    }

    private void Test1()
    {
      ITest it;

      it = new TestClass1();

      it.InformUser();
    }

    private void btnTest2_Click(object sender, EventArgs e)
    {
      Test2();
    }

    private void Test2()
    {
      ITest it;

      it = new TestClass2();

      it.InformUser();
    }
  }
}