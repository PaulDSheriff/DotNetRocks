using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CustomProvider_SampleCS
{
  class TestClass1 : ITest
  {
    public void InformUser()
    {
      MessageBox.Show("Hello from TestClass1");
    }
  }
}
