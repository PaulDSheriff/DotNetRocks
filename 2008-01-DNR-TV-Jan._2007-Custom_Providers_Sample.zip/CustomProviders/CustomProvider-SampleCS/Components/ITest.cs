using System;
using System.Collections.Generic;
using System.Text;

namespace CustomProvider_SampleCS
{
  interface ITest
  {
    void InformUser();
  }
}
