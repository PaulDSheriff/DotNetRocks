using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace CustomProvider_SampleCS
{
  class TestClass2 : ITest
  {
    public void InformUser()
    {
      MessageBox.Show("Hello from TestClass2");
    }
  }
}
