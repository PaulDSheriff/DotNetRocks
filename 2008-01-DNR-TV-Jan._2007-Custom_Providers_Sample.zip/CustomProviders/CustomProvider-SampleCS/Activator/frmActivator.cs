using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CustomProvider_SampleCS
{
  public partial class frmActivator : Form
  {
    public frmActivator()
    {
      InitializeComponent();
    }

    private void btnTest1_Click(object sender, EventArgs e)
    {
      CreateClass("CustomProvider_SampleCS.TestClass1");
    }

    private void btnTest2_Click(object sender, EventArgs e)
    {
      CreateClass("CustomProvider_SampleCS.TestClass2");
    }

    private void CreateClass(string ClassName)
    {
      ITest it;
      System.Type typ;

      typ = Type.GetType(ClassName);
      it = (ITest)System.Activator.CreateInstance(typ);

      it.InformUser();
    }
  }
}