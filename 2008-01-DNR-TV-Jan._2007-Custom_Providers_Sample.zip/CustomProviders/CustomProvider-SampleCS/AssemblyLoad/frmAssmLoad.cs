using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using CustomProviderInterfaces_CS;

namespace CustomProvider_SampleCS
{
  public partial class frmAssmLoad : Form
  {
    public frmAssmLoad()
    {
      InitializeComponent();
    }

    private void frmAssmLoad_Load(object sender, EventArgs e)
    {
      txtAssmName.Text = @"D:\MyStuff\Conference-Sessions\DotNet2.0\CustomProviders\Samples\CustomProvider-SampleCS\CustomProviderDLL-CS\bin\Debug\CustomProviderDLL-CS.dll";
      txtClassName.Text = "CustomProviderDLL_CS.TestClassDLL1";
    }

    private void btnTest_Click(object sender, EventArgs e)
    {
      CreateClass(txtAssmName.Text, txtClassName.Text);
    }

    private void CreateClass(string AssmName, string ClassName)
    {
      System.Reflection.Assembly assm;
      ITestDLL it;

      try
      {
        // Use Load method if assembly is in the GAC 
        // or in the Current Directory
        //assm = System.Reflection.Assembly.Load(AssmName);

        // Use LoadFile method if assembly is on file system, 
        // NOT in GAC, and not in the Current Directory
        assm = System.Reflection.Assembly.LoadFile(AssmName);

        // Create new instance of Class
        it = (ITestDLL)assm.CreateInstance(ClassName);

        it.InformUser();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

  }
}