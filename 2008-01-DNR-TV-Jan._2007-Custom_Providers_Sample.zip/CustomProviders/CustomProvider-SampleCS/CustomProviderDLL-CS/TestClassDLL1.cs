using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using CustomProviderInterfaces_CS;

namespace CustomProviderDLL_CS
{
  public class TestClassDLL1 : ITestDLL
  {
    public void InformUser()
    {
      MessageBox.Show("Hello from CustomProviderDLL_CS.TestClassDLL1");
    }
  }
}
