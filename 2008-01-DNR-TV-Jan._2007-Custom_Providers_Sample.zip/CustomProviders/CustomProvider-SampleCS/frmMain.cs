using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CustomProvider_SampleCS
{
  public partial class frmMain : Form
  {
    public frmMain()
    {
      InitializeComponent();
    }

    private void btnInterface_Click(object sender, EventArgs e)
    {
      frmInterface frm = new frmInterface();

      frm.Show();
    }

    private void btnActivator_Click(object sender, EventArgs e)
    {
      frmActivator frm = new frmActivator();

      frm.Show();
    }

    private void btnLoadAssm_Click(object sender, EventArgs e)
    {
      frmAssmLoad frm = new frmAssmLoad();

      frm.Show();
    }
  }
}