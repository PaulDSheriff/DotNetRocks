
Partial Class PwdChange
    Inherits System.Web.UI.Page

End Class
