﻿Imports System.Web.Security
Imports System.Collections.Specialized
Imports System.Web
Imports System.Configuration
Imports System.Xml

Public Class XmlRoleProvider
	Inherits RoleProvider

	Private mAppName As String
	Private mProviderName As String
	Private mFileName As String
	Private mConfig As NameValueCollection

	Public Overrides Sub Initialize(ByVal name As String, ByVal config As System.Collections.Specialized.NameValueCollection)
		MyBase.Initialize(name, config)

		Try
			mProviderName = name
			mConfig = config

			mFileName = HttpContext.Current.Server.MapPath(GetFromConfig("dataFile"))
			If mFileName = String.Empty Then
				Throw New ConfigurationErrorsException("'dataFile' attribute in web.config must be set to a valid file name.")
			End If

		Catch ex As Exception
			Throw New ConfigurationErrorsException(String.Format("Could not read the configuration settings from {0}.", mFileName), ex)
		End Try
	End Sub

#Region "Overridden Properties"
	Public Overrides ReadOnly Property Name() As String
		Get
			Return mProviderName
		End Get
	End Property

	Public Overrides Property ApplicationName() As String
		Get
			Return mAppName
		End Get
		Set(ByVal value As String)
			mAppName = value
		End Set
	End Property
#End Region

#Region "Methods Implemented"
	Public Overrides Sub AddUsersToRoles(ByVal usernames() As String, ByVal roleNames() As String)
		Dim xd As XmlDocument
		Dim nodeRole As XmlNode
		Dim nodeUser As XmlNode

		Try
			xd = GetXmlDocument()
			For Each roleName As String In roleNames
				nodeRole = xd.SelectSingleNode(String.Format("//Role[@roleName='{0}']", roleName))
				If nodeRole IsNot Nothing Then
					For Each userName As String In usernames
						nodeUser = nodeRole.SelectSingleNode(String.Format("User[@userName='{0}']", userName))
						If nodeUser Is Nothing Then
							InsertTextElement(nodeRole, "User", "", "userName", userName)
						Else
							Throw New HttpException(String.Format("User '{0}' is already in role '{1}'.", userName, roleName))
						End If
					Next
				End If
			Next
			xd.Save(mFileName)

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to add users to roles.", ex)
		End Try
	End Sub

	Public Overrides Sub CreateRole(ByVal roleName As String)
		Dim xd As XmlDocument
		Dim elem As XmlElement
		Dim node As XmlNode

		xd = GetXmlDocument()
		elem = xd.DocumentElement
		node = xd.SelectSingleNode(String.Format("//Role[@roleName='{0}']", roleName))

		If node Is Nothing Then
			InsertTextElement(elem, "Role", "", "roleName", roleName)
			xd.Save(mFileName)
		Else
			Throw New HttpException(String.Format("Role '{0}' already exists.", roleName))
		End If
	End Sub

	Public Overrides Function DeleteRole(ByVal roleName As String, ByVal throwOnPopulatedRole As Boolean) As Boolean
		Dim boolRet As Boolean = False
		Dim xd As XmlDocument
		Dim node As XmlNode

		Try
			xd = GetXmlDocument()
			node = xd.SelectSingleNode(String.Format("//Role[@roleName='{0}']", roleName))
			If node Is Nothing Then
				Throw New HttpException(String.Format("Role '{0}' was not found.", roleName))
			Else
				If throwOnPopulatedRole AndAlso node.HasChildNodes Then
					Throw New HttpException("Unable to delete role because it contains users.")
				Else
					node.ParentNode.RemoveChild(node)
					xd.Save(mFileName)
				End If
			End If
			boolRet = True

		Catch ex As HttpException
			Throw ex

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to delete role.", ex)
		End Try

		Return boolRet
	End Function

	Public Overrides Function GetAllRoles() As String()
		Dim astrRet() As String
		Dim xd As XmlDocument
		Dim nodeList As XmlNodeList
		Dim intLoop As Integer = 0

		Try
			xd = GetXmlDocument()
			nodeList = xd.SelectNodes("//Role")
			ReDim astrRet(nodeList.Count - 1)

			For Each node As XmlNode In nodeList
				astrRet(intLoop) = node.Attributes.GetNamedItem("roleName").Value
				intLoop += 1
			Next

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to retrieve roles.", ex)
		End Try

		Return astrRet
	End Function

	Public Overrides Function GetRolesForUser(ByVal username As String) As String()
		Dim astrRet() As String
		Dim xd As XmlDocument
		Dim nodeList As XmlNodeList
		Dim intLoop As Integer = 0

		Try
			xd = GetXmlDocument()
			nodeList = xd.SelectNodes( _
			 String.Format("//User[@userName='{0}']", username))
			ReDim astrRet(nodeList.Count - 1)
			For Each node As XmlNode In nodeList
				astrRet(intLoop) = node.ParentNode.Attributes.GetNamedItem("roleName").Value
				intLoop += 1
			Next

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to retrieve roles for user.", ex)
		End Try

		Return astrRet
	End Function

	Public Overrides Function GetUsersInRole(ByVal roleName As String) As String()
		Dim astrRet() As String
		Dim xd As XmlDocument
		Dim nodeList As XmlNodeList
		Dim intLoop As Integer = 0

		Try
			xd = GetXmlDocument()
			nodeList = xd.SelectNodes( _
			 String.Format("//Role[@roleName='{0}']/User", roleName))
			ReDim astrRet(nodeList.Count - 1)
			For Each node As XmlNode In nodeList
				astrRet(intLoop) = node.Attributes.GetNamedItem("userName").Value
				intLoop += 1
			Next

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to retrieve users for this role.", ex)
		End Try

		Return astrRet
	End Function

	Public Overrides Function IsUserInRole(ByVal username As String, ByVal roleName As String) As Boolean
		Dim xd As XmlDocument
		Dim nodeUser As XmlNode = Nothing

		Try
			xd = GetXmlDocument()
			nodeUser = xd.SelectSingleNode( _
			 String.Format("//Role[@roleName='{0}']/User[@userName='{1}']", roleName, username))

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to determine if user is in role.", ex)
		End Try

		Return (nodeUser IsNot Nothing)
	End Function

	Public Overrides Sub RemoveUsersFromRoles(ByVal usernames() As String, ByVal roleNames() As String)
		Dim xd As XmlDocument
		Dim node As XmlNode

		Try
			xd = GetXmlDocument()
			For Each roleName As String In roleNames
				For Each userName As String In usernames
					node = xd.SelectSingleNode(String.Format("//Role[@roleName='{0}']/User[@userName='{1}']", roleName, userName))
					If node IsNot Nothing Then
						node.ParentNode.RemoveChild(node)
					End If
				Next
			Next
			xd.Save(mFileName)

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to remove users from roles.", ex)
		End Try
	End Sub

	Public Overrides Function RoleExists(ByVal roleName As String) As Boolean
		Dim xd As XmlDocument
		Dim node As XmlNode = Nothing

		Try
			xd = GetXmlDocument()
			node = xd.SelectSingleNode( _
			 String.Format("//Role[@roleName='{0}']", roleName))

		Catch ex As Exception
			Throw New InvalidOperationException(String.Format("Unable to determine if role '{0}' exists.", roleName), ex)
		End Try

		Return (node IsNot Nothing)
	End Function
#End Region

#Region "Methods still to be implemented"
	Public Overrides Function FindUsersInRole(ByVal roleName As String, ByVal usernameToMatch As String) As String()
		' Need to Implement this
		Return Nothing
	End Function
#End Region

#Region "Private Methods"
	Private Function GetFromConfig(ByVal KeyName As String) As String
		Dim strRet As String = String.Empty

		If mConfig IsNot Nothing Then
			If mConfig(KeyName) IsNot Nothing Then
				strRet = mConfig(KeyName).ToString()
			End If
		End If

		Return strRet
	End Function

	Private Function GetXmlDocument() As XmlDocument
		Dim xd As New XmlDocument()

		Try
			xd.Load(mFileName)
			' You could cache the object here

		Catch ex As Exception
			Throw New System.IO.FileNotFoundException("The XML file" & mFileName & " does not exist.")

		End Try

		Return xd
	End Function

	Private Function InsertTextElement( _
	 ByVal node As XmlNode, ByVal tagName As String, _
	 ByVal Text As String) As XmlElement
		Return InsertTextElement(node, tagName, Text, String.Empty, String.Empty)
	End Function

	Private Function InsertTextElement( _
	 ByVal node As XmlNode, ByVal tagName As String, _
	 ByVal Text As String, ByVal AttributeName As String, _
	 ByVal AttributeValue As String) As XmlElement

		Dim elem As XmlElement
		Dim xd As XmlDocument = node.OwnerDocument

		elem = xd.CreateElement(tagName)
		elem.AppendChild(xd.CreateTextNode(Text))
		node.AppendChild(elem)
		If AttributeName <> String.Empty Then
			elem.SetAttribute(AttributeName, AttributeValue)
		End If

		Return elem
	End Function

#End Region
End Class
