Imports System.Xml
Imports Microsoft.VisualBasic

Public Class XmlMembershipProvider
	Inherits MembershipProvider

	Private Const PWD_NON_NUMERIC_CHARS As Integer = 0
	Private Const PWD_MIN_LENGTH As Integer = 5
	Private Const PWD_MAX_LENGTH As Integer = 10
	Private Const PWD_MAX_ATTEMPTS As Integer = 4
	Private Const PWD_ATTEMPT_WINDOW As Integer = 3

	Private mProviderName As String
	Private mFileName As String
	Private mConfig As NameValueCollection

	Public Sub New()
		MyBase.New()
	End Sub

	Public Overrides Sub Initialize(ByVal name As String, ByVal config As System.Collections.Specialized.NameValueCollection)
		MyBase.Initialize(name, config)

		Try
			mProviderName = name
			mConfig = config

			mFileName = HttpContext.Current.Server.MapPath(GetFromConfig("dataFile"))
			If mFileName = String.Empty Then
				Throw New ConfigurationErrorsException("'dataFile' attribute in web.config must be set to a valid file name.")
			End If

		Catch ex As Exception
			Throw New ConfigurationErrorsException(String.Format("Could not read the configuration settings from {0}.", mFileName), ex)
		End Try
	End Sub

#Region "Overridden Properties"
	Public Overrides Property ApplicationName() As String
		Get
			Return GetFromConfig("appName")
		End Get
		Set(ByVal value As String)
			Throw New InvalidOperationException("Can't set the ApplicationName property")
		End Set
	End Property

	Public Overrides ReadOnly Property Name() As String
		Get
			Return mProviderName
		End Get
	End Property

	Public Overrides ReadOnly Property EnablePasswordReset() As Boolean
		Get
			Return True
		End Get
	End Property

	Public Overrides ReadOnly Property EnablePasswordRetrieval() As Boolean
		Get
			Return True
		End Get
	End Property

	Public Overrides ReadOnly Property MaxInvalidPasswordAttempts() As Integer
		Get
			Return PWD_MAX_ATTEMPTS
		End Get
	End Property

	Public Overrides ReadOnly Property MinRequiredNonAlphanumericCharacters() As Integer
		Get
			Return PWD_NON_NUMERIC_CHARS
		End Get
	End Property

	Public Overrides ReadOnly Property MinRequiredPasswordLength() As Integer
		Get
			Return PWD_MIN_LENGTH
		End Get
	End Property

	Public Overrides ReadOnly Property PasswordAttemptWindow() As Integer
		Get
			Return PWD_ATTEMPT_WINDOW
		End Get
	End Property

	Public Overrides ReadOnly Property PasswordFormat() As System.Web.Security.MembershipPasswordFormat
		Get
			Return MembershipPasswordFormat.Hashed
		End Get
	End Property

	Public Overrides ReadOnly Property PasswordStrengthRegularExpression() As String
		Get
			Throw New Exception("The method or operation is not implemented.")
		End Get
	End Property

	Public Overrides ReadOnly Property RequiresQuestionAndAnswer() As Boolean
		Get
			Return False
		End Get
	End Property

	Public Overrides ReadOnly Property RequiresUniqueEmail() As Boolean
		Get
			Return True
		End Get
	End Property

#End Region

#Region "Methods Implemented"
	Public Overrides Function ChangePassword(ByVal username As String, ByVal oldPassword As String, ByVal newPassword As String) As Boolean
		Dim boolRet As Boolean = False
		Dim xd As XmlDocument
		Dim node As XmlNode

		' Change the user's password. 
		Try
			xd = GetXmlDocument()
			node = GetUserElement(xd, username, oldPassword)
			If node IsNot Nothing Then
				CType(node, XmlElement).SetAttribute("password", newPassword)
				xd.Save(mFileName)
				boolRet = True
			End If

		Catch ex As Exception
			Throw New MembershipPasswordException("Unable to change the password.", ex)
		End Try

		Return boolRet
	End Function

	Public Overrides Function CreateUser(ByVal username As String, ByVal password As String, ByVal email As String, ByVal passwordQuestion As String, ByVal passwordAnswer As String, ByVal isApproved As Boolean, ByVal providerUserKey As Object, ByRef status As System.Web.Security.MembershipCreateStatus) As System.Web.Security.MembershipUser
		Dim user As MembershipUser = Nothing
		Dim xd As XmlDocument
		Dim node As XmlNode
		Dim xmlUser As XmlElement

		status = MembershipCreateStatus.Success
		Try
			xd = GetXmlDocument()

			' Check to make sure the user doesn't already exist.
			node = xd.SelectSingleNode(String.Format("//User[@userName='{0}']", username))
			If node IsNot Nothing Then
				status = MembershipCreateStatus.DuplicateUserName
			Else
				xmlUser = xd.CreateElement("User")
				xd.DocumentElement.AppendChild(xmlUser)

				xmlUser.SetAttribute("userName", username)
				xmlUser.SetAttribute("password", password)
				xmlUser.SetAttribute("email", email)
				xmlUser.SetAttribute("passwordQuestion", passwordQuestion)
				xmlUser.SetAttribute("passwordAnswer", passwordAnswer)
				xmlUser.SetAttribute("isApproved", isApproved.ToString())
				user = GetUserInfo(xmlUser)
				xd.Save(mFileName)
			End If

		Catch
			' Don't throw any errors. Simply return an error.
			status = MembershipCreateStatus.ProviderError
		End Try

		Return user
	End Function

	Public Overrides Function DeleteUser(ByVal username As String, ByVal deleteAllRelatedData As Boolean) As Boolean
		Dim boolRet As Boolean = True
		Dim xd As XmlDocument
		Dim node As XmlNode

		Try
			xd = GetXmlDocument()
			' Check to make sure the user exists.
			node = xd.SelectSingleNode(String.Format("//User[@userName='{0}']", username))
			If node IsNot Nothing Then
				node.ParentNode.RemoveChild(node)
				xd.Save(mFileName)
			End If

		Catch
			boolRet = False
		End Try

		Return boolRet
	End Function

	Public Overrides Function FindUsersByEmail(ByVal emailToMatch As String, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
		Dim muc As New MembershipUserCollection
		Dim xd As XmlDocument

		xd = GetXmlDocument()
		If xd IsNot Nothing Then
			For Each node As XmlNode In xd.SelectNodes("//User")
				' Do a Case Insensitive Search
				If node.Attributes("email").Value.ToLower() = emailToMatch.ToLower() Then
					muc.Add(GetUserInfo(CType(node, XmlElement)))
				End If
			Next
		End If
		totalRecords = muc.Count

		Return muc
	End Function

	Public Overrides Function FindUsersByName(ByVal usernameToMatch As String, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
		Dim muc As New MembershipUserCollection
		Dim xd As XmlDocument

		xd = GetXmlDocument()
		If xd IsNot Nothing Then
			For Each node As XmlNode In xd.SelectNodes("//User")
				' Do a Case Insensitive Search
				If node.Attributes("userName").Value.ToLower() = usernameToMatch.ToLower() Then
					muc.Add(GetUserInfo(CType(node, XmlElement)))
				End If
			Next
		End If
		totalRecords = muc.Count

		Return muc
	End Function

	Public Overrides Function GetAllUsers(ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Security.MembershipUserCollection
		Dim muc As MembershipUserCollection

		muc = BuildUserCollection()

		totalRecords = muc.Count

		Return muc
	End Function

	' This method is called by the ChangePassword control
	Public Overloads Overrides Function GetUser(ByVal username As String, ByVal userIsOnline As Boolean) As System.Web.Security.MembershipUser
		Return GetUserByName(username)
	End Function

	Public Overrides Function GetUserNameByEmail(ByVal email As String) As String
		Dim strRet As String = String.Empty
		Dim xd As XmlDocument
		Dim node As XmlNode

		Try
			xd = GetXmlDocument()
			' Get user by email
			node = xd.SelectSingleNode(String.Format("//User[@email='{0}']", email))
			If node IsNot Nothing Then
				strRet = node.Attributes("userName").Value
			End If

		Catch ex As Exception
			Throw New InvalidOperationException("Unable to find user name by email.", ex)

		End Try

		Return strRet
	End Function

	Public Overrides Function ResetPassword(ByVal username As String, ByVal answer As String) As String
		Dim strRet As String = String.Empty

		If Me.EnablePasswordReset Then
			strRet = Membership.GeneratePassword(PWD_MAX_LENGTH, _
		PWD_NON_NUMERIC_CHARS)
		End If

		Return strRet
	End Function

	Public Overrides Sub UpdateUser(ByVal user As System.Web.Security.MembershipUser)
		Dim xd As XmlDocument
		Dim node As XmlNode

		xd = GetXmlDocument()
		node = xd.SelectSingleNode(String.Format("//User[@userName='{0}']", user.UserName))
		If node IsNot Nothing Then
			SetUserInfo(user, node)
		End If

		xd.Save(mFileName)
	End Sub

	Public Overrides Function ValidateUser(ByVal username As String, ByVal password As String) As Boolean
		Dim boolRet As Boolean = False
		Dim xd As XmlDocument
		Dim xmlUser As XmlElement

		' Check to see if user exists
		xd = GetXmlDocument()
		If xd IsNot Nothing Then
			xmlUser = GetUserElement(xd, username, password)
			boolRet = (xmlUser IsNot Nothing)
		End If

		Return boolRet
	End Function
#End Region

#Region "Methods still to be implemented"
	Public Overrides Function ChangePasswordQuestionAndAnswer(ByVal username As String, ByVal password As String, ByVal newPasswordQuestion As String, ByVal newPasswordAnswer As String) As Boolean
		' Need to implement this
		Return True
	End Function

	Public Overrides Function GetNumberOfUsersOnline() As Integer
		' Need to implement this
		Return 0
	End Function

	Public Overrides Function GetPassword(ByVal username As String, ByVal answer As String) As String
		' Need to implement this
		Return String.Empty
	End Function

	Public Overloads Overrides Function GetUser(ByVal providerUserKey As Object, ByVal userIsOnline As Boolean) As System.Web.Security.MembershipUser
		' Need to implement this
		Return Nothing
	End Function

	Public Overrides Function UnlockUser(ByVal userName As String) As Boolean
		' Still needs to be implemented
		Return True
	End Function

#End Region

#Region "Private Methods"
	Private Function GetFromConfig(ByVal keyName As String) As String
		Dim strRet As String = String.Empty

		If mConfig IsNot Nothing Then
			If mConfig(keyName) IsNot Nothing Then
				strRet = mConfig(keyName).ToString()
			End If
		End If

		Return strRet
	End Function

	Private Function GetXmlDocument() As XmlDocument
		Dim xd As New XmlDocument()

		Try
			xd.Load(mFileName)
			' You could cache the object here

		Catch ex As Exception
			Throw New System.IO.FileNotFoundException("The XML file" & mFileName & " does not exist.", ex)

		End Try

		Return xd
	End Function

	Private Function GetUserByName(ByVal userName As String) As MembershipUser
		Dim xd As XmlDocument
		Dim node As XmlNode = Nothing

		xd = GetXmlDocument()
		node = xd.SelectSingleNode( _
		 String.Format("//User[(@userName='{0}')]", userName))

		Return GetUserInfo(CType(node, XmlElement))
	End Function

	Private Function GetUserElement(ByVal xd As XmlDocument, ByVal userName As String, ByVal password As String) As XmlElement
		Dim node As XmlNode = Nothing

		' Given a user name and a password, retrieve the correct user from 
		' the XML document. Note that XML is case-sensitive for both 
		' username and password!
		' Throw all exceptions back to the caller.
		node = xd.SelectSingleNode( _
		 String.Format("//User[(@userName='{0}') and (@password='{1}')]", _
		 userName, password))

		Return CType(node, XmlElement)
	End Function

	Private Function GetUserElementByEmail(ByVal xd As XmlDocument, ByVal email As String) As XmlElement
		Dim node As XmlNode = Nothing

		' Given an email address, retrieve the correct user from 
		' the XML document. Note that XML is case-sensitive for both 
		' username and password!
		' Throw all exceptions back to the caller.
		node = xd.SelectSingleNode( _
		 String.Format("//User[(@email='{0}')]", email))

		Return CType(node, XmlElement)
	End Function

	Private Function BuildUserCollection() As MembershipUserCollection
		Dim muc As New MembershipUserCollection
		Dim xd As XmlDocument

		xd = GetXmlDocument()
		If xd IsNot Nothing Then
			For Each node As XmlNode In xd.SelectNodes("//User")
				muc.Add(GetUserInfo(CType(node, XmlElement)))
			Next
		End If

		Return muc
	End Function

	Private Function GetUserInfo(ByVal elem As XmlElement) As MembershipUser
		' Given an XML element, retrieve a MembershipUser object.
		Dim user As New MembershipUser(mProviderName, _
		 elem.GetAttribute("userName"), _
		 elem.GetAttribute("userName"), _
		 elem.GetAttribute("email"), _
		 elem.GetAttribute("passwordQuestion"), _
		 elem.GetAttribute("passwordAnswer"), _
		 Convert.ToBoolean(elem.GetAttribute("isApproved")), _
		 False, Date.Today, Date.Today, Date.Today, Date.Today, Date.Today)

		Return user
	End Function

	Private Function SetUserInfo(ByVal user As MembershipUser, ByVal node As XmlNode) As XmlNode
		Dim elem As XmlElement

		elem = CType(node, XmlElement)
		elem.Attributes("userName").Value = user.UserName
		elem.Attributes("email").Value = user.Email
		elem.Attributes("passwordQuestion").Value = user.PasswordQuestion
		elem.Attributes("isApproved").Value = user.IsApproved.ToString()

		Return elem
	End Function
#End Region
End Class
