
Partial Class AddUser
    Inherits System.Web.UI.Page

End Class
