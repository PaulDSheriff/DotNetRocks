Imports Microsoft.VisualBasic

Partial Class ShowAllRoles_aspx
  Inherits System.Web.UI.Page

	Private Const COL_ROLE_NAME As Integer = 1

  Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
    If Not Page.IsPostBack Then
      DisplayRoles()

			ddlUser.DataTextField = "Username"
      ddlUser.DataSource = Membership.GetAllUsers()

      ddlUserAdd.DataTextField = "UserName"
      ddlUserAdd.DataSource = Membership.GetAllUsers()

      ddlUserDelete.DataTextField = "UserName"
      ddlUserDelete.DataSource = Membership.GetAllUsers()

      ddlUser.DataBind()
      ddlUserAdd.DataBind()
      ddlUserDelete.DataBind()

      BindRoleLists()
		End If

    lblResults.Text = String.Empty
		lblStatus.Text = String.Empty

    btnDeleteUserFromRole.Enabled = (ddlRoleDelete.Items.Count > 0)
  End Sub

  Private Sub BindRoleLists()
    ddlRoleAdd.DataSource = Roles.GetAllRoles()
		ddlRole.DataSource = Roles.GetAllRoles()

    If ddlUserDelete.SelectedItem IsNot Nothing Then
      ddlRoleDelete.DataSource = Roles.GetRolesForUser(ddlUserDelete.SelectedItem.Text)
    Else
      ddlRoleDelete.DataSource = Roles.GetAllRoles()
		End If

    ddlRoleAdd.DataBind()
    ddlRole.DataBind()
    ddlRoleDelete.DataBind()
  End Sub

  Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs)
    Try
			Roles.CreateRole(txtRole.Text)

      ddlRoleAdd.DataSource = Roles.GetAllRoles()
      ddlRoleAdd.DataBind()

      ddlRole.DataSource = Roles.GetAllRoles()
      ddlRole.DataBind()

      txtRole.Text = String.Empty
      DisplayRoles()

    Catch ex As Exception
      lblStatus.Text = ex.Message
    End Try
  End Sub

  Private Sub DisplayRoles()
    grdRoles.DataSource = Roles.GetAllRoles()
    grdRoles.DataBind()
  End Sub

	Private Sub grdRoles_RowCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdRoles.RowCreated
		If e.Row.RowType = DataControlRowType.DataRow Then
			Dim strRole As String = Roles.GetAllRoles()(e.Row.RowIndex)
			e.Row.Cells(1).Text = strRole
			e.Row.Cells(2).Text = String.Join(", ", Roles.GetUsersInRole(strRole))
		End If
	End Sub

	Private Sub grdRoles_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdRoles.RowDeleting
		Dim strRole As String = grdRoles.Rows(e.RowIndex).Cells(COL_ROLE_NAME).Text

		Try
			Roles.DeleteRole(strRole, True)

			DisplayRoles()

		Catch ex As Exception
			lblStatus.Text = ex.Message
		End Try
	End Sub

  Sub btnCheckUserInRole_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		Dim boolRet As Boolean

		boolRet = Roles.IsUserInRole(ddlUser.SelectedItem.Text, ddlRole.SelectedItem.Text)

		lblResults.Text = boolRet.ToString()
  End Sub

	Sub btnAddUserToRole_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		Dim strUser As String

		Try
			strUser = ddlUserAdd.SelectedItem.Text

			Roles.AddUserToRole(strUser, ddlRoleAdd.SelectedItem.Text)

			DisplayRolesForDelete(strUser)
			DisplayRoles()

		Catch ex As Exception
			lblStatus.Text = ex.Message
		End Try
	End Sub

  Private Sub DisplayRolesForDelete(ByVal strUser As String)
    ddlRoleDelete.DataSource = Roles.GetRolesForUser(strUser)
		ddlRoleDelete.DataBind()

    btnDeleteUserFromRole.Enabled = (ddlRoleDelete.Items.Count > 0)
  End Sub

  Sub ddlUserDelete_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
    DisplayRolesForDelete(ddlUserDelete.SelectedItem.Text)
  End Sub

  Sub btnDeleteUserFromRole_Click(ByVal sender As Object, ByVal e As System.EventArgs)
		Dim strUser As String

		Try
			strUser = ddlUserDelete.SelectedItem.Text

			If ddlRoleDelete.SelectedItem IsNot Nothing Then
				Roles.RemoveUserFromRole(strUser, ddlRoleDelete.SelectedItem.Text)
				DisplayRolesForDelete(strUser)
				DisplayRoles()
			End If

		Catch ex As Exception
			lblStatus.Text = ex.Message
		End Try
  End Sub
End Class
