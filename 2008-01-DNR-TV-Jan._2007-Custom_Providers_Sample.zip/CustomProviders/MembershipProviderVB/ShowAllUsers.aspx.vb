Imports Microsoft.VisualBasic

Partial Class ShowAllUsers_aspx
  Inherits System.Web.UI.Page

	Private Const USERNAME_COL As Integer = 8

  Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
		DisplayUsers()

    lblStatus.Text = String.Empty
	End Sub

	Private Sub DisplayUsers()
		grdUsers.Caption = "All Users"
		grdUsers.DataSource = Membership.GetAllUsers()
		grdUsers.DataBind()
	End Sub

	Private Sub ClearControls()
		txtEmail.Text = String.Empty
		txtUserName.Text = String.Empty
		txtPassword.Text = String.Empty
		txtPasswordQuestion.Text = String.Empty
		txtPasswordAnswer.Text = String.Empty

		txtNewPassword.Text = String.Empty
		txtNewPasswordQuestion.Text = String.Empty
		txtNewPasswordAnswer.Text = String.Empty
		txtOldPassword.Text = String.Empty
	End Sub

	Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
		Dim status As MembershipCreateStatus

		Try
			Membership.CreateUser(txtUserName.Text, _
			 txtPassword.Text, txtEmail.Text, _
			 txtPasswordQuestion.Text, txtPasswordAnswer.Text, _
			 True, status)
			lblStatus.Text = "Status = " & status.ToString()

			ClearControls()
			DisplayUsers()

		Catch ex As Exception
			lblStatus.Text = ex.Message

		End Try
	End Sub

	Private Sub grdUsers_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdUsers.RowDeleting
		Dim strUser As String

		Try
			strUser = grdUsers.Rows(e.RowIndex).Cells(USERNAME_COL).Text

			Membership.DeleteUser(strUser)

			DisplayUsers()

		Catch ex As Exception
			lblStatus.Text = ex.Message
		End Try
	End Sub

  Private Sub grdUsers_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles grdUsers.SelectedIndexChanging
		Dim strUser As String

		strUser = grdUsers.Rows(e.NewSelectedIndex).Cells(USERNAME_COL).Text

		pnlPassword.Visible = True

    txtSelectedUserName.Text = strUser
  End Sub

  Private Sub btnChangePassword_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnChangePassword.Click
		Dim user As MembershipUser

		user = Membership.GetUser(txtSelectedUserName.Text)
    If user IsNot Nothing Then
      If user.ChangePassword(txtOldPassword.Text, txtNewPassword.Text) Then
				If user.ChangePasswordQuestionAndAnswer( _
				 txtNewPassword.Text, txtNewPasswordQuestion.Text, _
				 txtNewPasswordAnswer.Text) Then
					lblStatus.Text = "Success!"
				Else
					lblStatus.Text = "Unable to change password question/answer."
				End If
      Else
        lblStatus.Text = "Unable to change the password."
      End If
		End If

    DisplayUsers()
  End Sub

  Sub btnFindUsersByEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFindUsersByEmail.Click
    grdUsers.Caption = "Find Users by Email (" & txtFindByEmail.Text & ")"
    grdUsers.DataSource = Membership.FindUsersByEmail(txtFindByEmail.Text)
    grdUsers.DataBind()
  End Sub

	Sub btnFindUsersByName_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFindUsersByName.Click
		grdUsers.Caption = "Find Users by Name (" & txtFindByName.Text & ")"
		grdUsers.DataSource = Membership.FindUsersByName(txtFindByName.Text)
		grdUsers.DataBind()
	End Sub

	Sub btnShowAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnShowAll.Click
		DisplayUsers()
	End Sub

	Sub btnResetPassword_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnResetPassword.Click
		Dim user As MembershipUser

		Try
			user = Membership.GetUser(txtSelectedUserName.Text)

			lblStatus.Text = "New password = " & user.ResetPassword(txtPasswordAnswer.Text)

		Catch ex As Exception
			lblStatus.Text = ex.Message
		End Try
	End Sub
End Class
