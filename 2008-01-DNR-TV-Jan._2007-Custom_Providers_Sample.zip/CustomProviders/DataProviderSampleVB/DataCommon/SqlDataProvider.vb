Imports System.Data.SqlClient

Namespace DataCommon
	Public Class SqlDataProvider
		Implements IDataProvider

#Region "SQL Server Specific Methods"
		' The following methods only handle SQL Server
		Public Function CreateConnection() As IDbConnection Implements IDataProvider.CreateConnection
			Dim cnn As New SqlConnection

			Return cnn
		End Function

		Public Function CreateCommand() As IDbCommand Implements IDataProvider.CreateCommand
			Dim cmd As New SqlCommand

			Return cmd
		End Function

		Public Function CreateDataAdapter() As IDbDataAdapter Implements IDataProvider.CreateDataAdapter
			Dim da As New SqlDataAdapter

			Return da
		End Function
#End Region
	End Class
End Namespace
