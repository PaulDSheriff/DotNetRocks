Imports System.Data

Namespace DataCommon
	Public Interface IDataProvider
		Function CreateConnection() As IDbConnection
		Function CreateCommand() As IDbCommand
		Function CreateDataAdapter() As IDbDataAdapter
	End Interface
End Namespace