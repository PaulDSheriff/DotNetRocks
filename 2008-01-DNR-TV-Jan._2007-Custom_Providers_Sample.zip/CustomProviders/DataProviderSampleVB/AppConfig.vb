Imports System.Configuration

Public Class AppConfig
	Public Shared ReadOnly Property ConnectString() As String
		Get
			Dim ProviderName As String

			' Get Provider Name
			ProviderName = ConfigurationManager.AppSettings("ProviderName")

			' Get Connect String
			Return ConfigurationManager.ConnectionStrings(ProviderName).ConnectionString
		End Get
	End Property
End Class
