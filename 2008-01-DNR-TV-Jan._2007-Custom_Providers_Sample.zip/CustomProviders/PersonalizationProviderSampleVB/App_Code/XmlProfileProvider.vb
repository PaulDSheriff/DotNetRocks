Imports Microsoft.VisualBasic
Imports System.Xml
Imports System.Web
Imports System.Configuration
Imports System.Collections.Specialized
Imports System.Configuration.Provider
Imports System.IO
Imports System.Security.Permissions

Public Class XmlProfileProvider
	Inherits ProfileProvider

	Private mAppName As String
	Private mFileName As String

	Public Overrides Sub Initialize(ByVal name As String, ByVal config As NameValueCollection)
		' Store application name
		mAppName = name

		' Get File Name from Path attribute in Web.Config
		mFileName = HttpContext.Current.Server.MapPath(GetFromConfig(config, "fileName"))
		If mFileName.Trim() = String.Empty Then
			Throw New System.Configuration.ConfigurationErrorsException("'fileName' attribute in your Web.Config file must be set to a valid path and file name")
		End If

		' Call base Initialize method
		MyBase.Initialize(name, config)

		' Check for appropriate File Permissions
		Dim permission As FileIOPermission = _
		 New FileIOPermission(FileIOPermissionAccess.AllAccess, HttpContext.Current.Server.MapPath("~/XML"))
		permission.Demand()
	End Sub

	Public Overrides Property ApplicationName() As String
		Get
			Return mAppName
		End Get
		Set(ByVal value As String)
			mAppName = value
		End Set
	End Property

	Public Overrides Function GetPropertyValues( _
	 ByVal context As SettingsContext, _
	 ByVal collection As SettingsPropertyCollection) _
	 As SettingsPropertyValueCollection
		Dim node As XmlNode
		Dim childNode As XmlNode
		Dim spvc As New SettingsPropertyValueCollection
		Dim spv As SettingsPropertyValue
		Dim xd As XmlDocument

		' Retrieve the Profile XML Document 
		xd = GetXmlDocument()
		If xd IsNot Nothing Then
			' Find the user in the XML File
			node = GetUserNode(xd, context.Item("UserName").ToString())

			For Each sp As SettingsProperty In collection
				spv = New SettingsPropertyValue(sp)

				' See if we can find the node in the Profile.xml file
				childNode = node.SelectSingleNode(sp.Name)
				If childNode IsNot Nothing Then
					spv.Property.PropertyType = sp.PropertyType
					spv.PropertyValue = _
					 Convert.ChangeType(childNode.InnerText, sp.PropertyType)
				End If

				spvc.Add(spv)
			Next
		End If

		Return spvc
	End Function

	Public Overrides Sub SetPropertyValues( _
	 ByVal context As SettingsContext, _
	 ByVal collection As SettingsPropertyValueCollection)
		Dim node As XmlNode
		Dim propertyNode As XmlNode
		Dim xd As XmlDocument

		' Get an XML Document object
		xd = GetXmlDocument()
		If xd IsNot Nothing Then
			node = GetUserNode(xd, context.Item("UserName").ToString())
			If node Is Nothing Then
				' Create new XmlNode
			Else
				' Write to the XML file here.
				For Each spv As SettingsPropertyValue In collection
					propertyNode = node.SelectSingleNode(spv.Property.Name)
					If propertyNode Is Nothing Then
						' Create the node
						propertyNode = node.OwnerDocument.CreateElement(spv.Property.Name)
						node.AppendChild(propertyNode)
					End If
					propertyNode.InnerText = spv.PropertyValue.ToString()
				Next
			End If
			xd.Save(mFileName)
		End If
	End Sub

#Region "Private Methods"
	Private Function GetUserNode(ByVal xd As XmlDocument, ByVal UserName As String) As XmlNode
		Return xd.SelectSingleNode( _
		  String.Format("Profiles/Profile[(@userName='{0}')]", UserName))
	End Function

	Private Function GetFromConfig(ByVal config As NameValueCollection, ByVal KeyName As String) As String
		Dim strReturn As String = String.Empty

		If config IsNot Nothing Then
			If Not String.IsNullOrEmpty(config(KeyName)) Then
				strReturn = config(KeyName)
			End If
		End If

		Return strReturn
	End Function

	Private Function GetXmlDocument() As XmlDocument
		Dim xd As New XmlDocument()

		Try
			xd.Load(mFileName)

			' Cache the XmlDocument object here

		Catch ex As Exception
			Throw New FileNotFoundException("Your XML File: " & mFileName & " does not exist!")

		End Try

		Return xd
	End Function
#End Region

#Region "Methods Not Implemented Yet"
	Public Overrides Function DeleteInactiveProfiles(ByVal authenticationOption As System.Web.Profile.ProfileAuthenticationOption, ByVal userInactiveSinceDate As Date) As Integer
		Throw New NotSupportedException()
	End Function

	Public Overloads Overrides Function DeleteProfiles(ByVal usernames() As String) As Integer
		Throw New NotSupportedException()
	End Function

	Public Overloads Overrides Function DeleteProfiles(ByVal profiles As System.Web.Profile.ProfileInfoCollection) As Integer
		Throw New NotSupportedException()
	End Function

	Public Overrides Function FindInactiveProfilesByUserName(ByVal authenticationOption As System.Web.Profile.ProfileAuthenticationOption, ByVal usernameToMatch As String, ByVal userInactiveSinceDate As Date, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Profile.ProfileInfoCollection
		Throw New NotSupportedException()
	End Function

	Public Overrides Function FindProfilesByUserName(ByVal authenticationOption As System.Web.Profile.ProfileAuthenticationOption, ByVal usernameToMatch As String, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Profile.ProfileInfoCollection
		Throw New NotSupportedException()
	End Function

	Public Overrides Function GetAllInactiveProfiles(ByVal authenticationOption As System.Web.Profile.ProfileAuthenticationOption, ByVal userInactiveSinceDate As Date, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Profile.ProfileInfoCollection
		Throw New NotSupportedException()
	End Function

	Public Overrides Function GetAllProfiles(ByVal authenticationOption As System.Web.Profile.ProfileAuthenticationOption, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As System.Web.Profile.ProfileInfoCollection
		Throw New NotSupportedException()
	End Function

	Public Overrides Function GetNumberOfInactiveProfiles(ByVal authenticationOption As System.Web.Profile.ProfileAuthenticationOption, ByVal userInactiveSinceDate As Date) As Integer
		Throw New NotSupportedException()
	End Function
#End Region

End Class
