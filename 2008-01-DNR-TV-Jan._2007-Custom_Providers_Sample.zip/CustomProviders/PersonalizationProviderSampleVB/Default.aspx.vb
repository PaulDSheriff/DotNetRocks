Partial Class _Default
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		If Not Page.IsPostBack Then
			txtName.Text = Profile.Name
			txtLastVisitDate.Text = Profile.LastVisitedDate
		End If
	End Sub

	Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
		Profile.Name = txtName.Text
		Profile.LastVisitedDate = txtLastVisitDate.Text

		' The following code is NOT necessary
		'Profile.Save()
	End Sub
End Class
