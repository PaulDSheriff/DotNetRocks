﻿using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using TimeTrack.EntityClasses;

namespace TimeTrack.WinPhone
{
  public partial class App : Application
  {
    /// <summary>
    /// Get/Set the current TimeSheet View Model
    /// </summary>
    public AddTimeSheetViewModel TimeSheetModel { get; set; }

    // Restore TimeSheet Object When App is Activated after Tombstoning
    private void Application_Activated(object sender, ActivatedEventArgs e)
    {
      // Restore Time Sheet View Model
      if (PhoneApplicationService.Current.State.ContainsKey("TimeSheetObject"))
        (Application.Current as App).TimeSheetModel = (AddTimeSheetViewModel)PhoneApplicationService.Current.State["TimeSheetObject"];
    }

    // Store Current TimeSheet Object When App is Tombstoned
    private void Application_Deactivated(object sender, DeactivatedEventArgs e)
    {
      // Save Time Sheet View Model
      PhoneApplicationService.Current.State["TimeSheetObject"] = (Application.Current as App).TimeSheetModel;
    }

    /// <summary>
    /// Ensure that the "Global" TimeSheet View Model is valid
    /// </summary>
    public void InitTimeSheetViewModel()
    {
      if ((Application.Current as App).TimeSheetModel == null)
      {
        // Create new time sheet view model
        (Application.Current as App).TimeSheetModel = new AddTimeSheetViewModel();
        // Initialize to valid start state
        // Nothing can be null if you want to serialize it
        (Application.Current as App).TimeSheetModel.Init();
        // Store into Phone State Bag
        PhoneApplicationService.Current.State["TimeSheetObject"] = (Application.Current as App).TimeSheetModel;
      }
    }

    #region Normal Phone Stuff
    /// <summary>
    /// Provides easy access to the root frame of the Phone Application.
    /// </summary>
    /// <returns>The root frame of the Phone Application.</returns>
    public PhoneApplicationFrame RootFrame { get; private set; }

    /// <summary>
    /// Constructor for the Application object.
    /// </summary>
    public App()
    {
      // Global handler for uncaught exceptions. 
      UnhandledException += Application_UnhandledException;

      // Show graphics profiling information while debugging.
      if (System.Diagnostics.Debugger.IsAttached)
      {
        // Display the current frame rate counters.
        Application.Current.Host.Settings.EnableFrameRateCounter = true;

        // Show the areas of the app that are being redrawn in each frame.
        //Application.Current.Host.Settings.EnableRedrawRegions = true;

        // Enable non-production analysis visualization mode, 
        // which shows areas of a page that are being GPU accelerated with a colored overlay.
        //Application.Current.Host.Settings.EnableCacheVisualization = true;
      }

      // Standard Silverlight initialization
      InitializeComponent();

      // Phone-specific initialization
      InitializePhoneApplication();
    }

    // Code to execute when the application is launching (eg, from Start)
    // This code will not execute when the application is reactivated
    private void Application_Launching(object sender, LaunchingEventArgs e)
    {
    }

    // Code to execute when the application is closing (eg, User hit Back)
    // This code will not execute when the application is deactivated
    private void Application_Closing(object sender, ClosingEventArgs e)
    {
    }

    // Code to execute if a navigation fails
    private void RootFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
    {
      if (System.Diagnostics.Debugger.IsAttached)
      {
        // A navigation has failed; break into the debugger
        System.Diagnostics.Debugger.Break();
      }
    }

    // Code to execute on Unhandled Exceptions
    private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
    {
      if (System.Diagnostics.Debugger.IsAttached)
      {
        // An unhandled exception has occurred; break into the debugger
        System.Diagnostics.Debugger.Break();
      }
    }
    #endregion

    #region Phone application initialization

    // Avoid double-initialization
    private bool phoneApplicationInitialized = false;

    // Do not add any additional code to this method
    private void InitializePhoneApplication()
    {
      if (phoneApplicationInitialized)
        return;

      // Create the frame but don't set it as RootVisual yet; this allows the splash
      // screen to remain active until the application is ready to render.
      RootFrame = new PhoneApplicationFrame();
      RootFrame.Navigated += CompleteInitializePhoneApplication;

      // Handle navigation failures
      RootFrame.NavigationFailed += RootFrame_NavigationFailed;

      // Ensure we don't initialize again
      phoneApplicationInitialized = true;
    }

    // Do not add any additional code to this method
    private void CompleteInitializePhoneApplication(object sender, NavigationEventArgs e)
    {
      // Set the root visual to allow the application to render
      if (RootVisual != RootFrame)
        RootVisual = RootFrame;

      // Remove this handler since it is no longer needed
      RootFrame.Navigated -= CompleteInitializePhoneApplication;
    }

    #endregion
  }
}