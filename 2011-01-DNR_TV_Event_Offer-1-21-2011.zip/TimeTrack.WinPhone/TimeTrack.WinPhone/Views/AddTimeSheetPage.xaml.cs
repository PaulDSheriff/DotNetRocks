﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TimeTrack.WinPhone
{
  public partial class AddTimeSheetPage : PhoneApplicationPage
  {
    private AddTimeSheetViewModel _ViewModel = null;

    #region Constructor
    public AddTimeSheetPage()
    {
      InitializeComponent();
      
      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Get Application-Wide AddTimeSheetViewModel instance
      _ViewModel = (Application.Current as App).TimeSheetModel;

      // Set ViewModel object to Page's Data Context
      this.DataContext = _ViewModel;
    }
    #endregion

    #region Event Procedures
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/CustomerLookupPage.xaml", UriKind.Relative));
    }

    private void btnProject_Click(object sender, RoutedEventArgs e)
    {
      if (_ViewModel.SelectedCustomer == null)
        MessageBox.Show("Select a Customer First", "Select Customer", MessageBoxButton.OK);
      else
        NavigationService.Navigate(new Uri("/Views/ProjectLookupPage.xaml", UriKind.Relative));
    }

    private void btnEmployee_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/EmployeeLookupPage.xaml", UriKind.Relative));
    }

    private void btnDesc_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/AddDescriptionPage.xaml", UriKind.Relative));
    }

    private void btnClear_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Init();
    }
    #endregion

    #region Insert/Validate Method
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      if (_ViewModel.Validate())
      {
        // Insert new Time Sheet entry
        _ViewModel.Insert();
        // Reset Time Sheet Data
        _ViewModel.PrepareForNew();
      }
    }
    #endregion
  }
}