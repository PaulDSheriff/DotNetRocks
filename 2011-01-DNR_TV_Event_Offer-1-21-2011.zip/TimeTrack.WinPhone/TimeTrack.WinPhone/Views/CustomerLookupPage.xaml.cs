﻿using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

using TimeTrack.EntityClasses;

namespace TimeTrack.WinPhone
{
  public partial class CustomerLookupPage : PhoneApplicationPage
  {
    private CustomerViewModel _ViewModel = null;

    #region Constructor
    public CustomerLookupPage()
    {
      InitializeComponent();

      // Grab the Instance of the ViewModel
      _ViewModel = (CustomerViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event Procedure
    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetCustomers();
    }
    #endregion

    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Get Selected Customer and 
      // Store into Application Level
      (Application.Current as App).
        TimeSheetModel.SelectedCustomer = 
          (Customer)lstData.SelectedItem;

      NavigationService.GoBack();
    }

    #region TextChanged Event
    private void txtName_TextChanged(object sender, TextChangedEventArgs e)
    {
      _ViewModel.FilterCustomers(txtName.Text.Trim());
    }
    #endregion

    #region GoBack Click Event
    private void btnGoBack_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.GoBack();
    }
    #endregion
  }
}