﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using TimeTrack.EntityClasses;

namespace TimeTrack.WinPhone
{
  public partial class DisplayTimeSheetsPage : PhoneApplicationPage
  {
    private DisplayTimeSheetsViewModel _ViewModel = null;

    #region Constructor
    public DisplayTimeSheetsPage()
    {
      InitializeComponent();

      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Grab the Instance of the ViewModel
      _ViewModel = (DisplayTimeSheetsViewModel)this.Resources["viewModel"];
    }
    #endregion

    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      Customer selected;

      // Store currently selected customer into ViewModel if applicable
      selected = (Application.Current as App).TimeSheetModel.SelectedCustomer;
      if (selected.CustomerId != -1)
      {
        _ViewModel.SelectedCustomer = selected;
      }
    }

    #region Customers Click Event
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      ResetUI();
      NavigationService.Navigate(new Uri("/Views/CustomerLookupPage.xaml", UriKind.Relative));
    }
    #endregion

    #region Search Click Event
    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      Customer selected;

      selected = (Application.Current as App).TimeSheetModel.SelectedCustomer;

      if (selected == null || selected.CustomerId == -1)
      {
        lstData.ItemTemplate = (DataTemplate)this.Resources["tmplWithCustomer"];
        _ViewModel.GetAllTimeSheets();
      }
      else
      {
        lstData.ItemTemplate = (DataTemplate)this.Resources["tmplProjectOnly"];
        _ViewModel.GetTimeSheetsByCustomer((Application.Current as App).TimeSheetModel.SelectedCustomer);
      }
    }
    #endregion

    #region Reset Click Event
    private void btnReset_Click(object sender, RoutedEventArgs e)
    {
      (Application.Current as App).TimeSheetModel.SelectedCustomer = new Customer();
      (Application.Current as App).TimeSheetModel.SelectedCustomer.CustomerId = -1;
      _ViewModel.SelectedCustomer = (Application.Current as App).TimeSheetModel.SelectedCustomer;
      ResetUI();
    }
    #endregion

    #region ResetUI Method
    private void ResetUI()
    {
      _ViewModel.DataCollection = new System.Collections.ObjectModel.ObservableCollection<TimeSheet>();
      _ViewModel.IsMessageVisible = false;
      lstData.SelectedIndex = -1;      
    }
    #endregion
  }
}