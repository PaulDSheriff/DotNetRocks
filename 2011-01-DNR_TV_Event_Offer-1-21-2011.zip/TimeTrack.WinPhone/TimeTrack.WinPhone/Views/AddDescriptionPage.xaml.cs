﻿using System.Windows;
using Microsoft.Phone.Controls;

namespace TimeTrack.WinPhone
{
  public partial class AddDescriptionPage : PhoneApplicationPage
  {
    public AddDescriptionPage()
    {
      InitializeComponent();

      this.DataContext = (Application.Current as App).TimeSheetModel;
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.GoBack();
    }
  }
}