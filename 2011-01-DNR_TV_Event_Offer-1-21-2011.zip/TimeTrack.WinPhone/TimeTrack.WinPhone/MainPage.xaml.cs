﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

namespace TimeTrack.WinPhone
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnAddTimeSheet_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/AddTimeSheetPage.xaml", UriKind.Relative));
    }

    private void btnDisplayTimeSheets_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/DisplayTimeSheetsPage.xaml", UriKind.Relative));
    }
  }
}