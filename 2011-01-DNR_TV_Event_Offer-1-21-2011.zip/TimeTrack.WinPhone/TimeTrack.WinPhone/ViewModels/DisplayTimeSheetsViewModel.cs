﻿using System.Collections.ObjectModel;
using Common.Library;
using TimeTrack.EntityClasses;
using TimeTrack.WinPhone.TimeSheetServiceReference;
using System.Windows;

namespace TimeTrack.WinPhone
{
  public class DisplayTimeSheetsViewModel : ViewModelBase
  {
    #region Constructor
    public DisplayTimeSheetsViewModel()
    {
      IsMessageVisible = false;
    }
    #endregion

    #region Private Variables
    private Customer _SelectedCustomer;
    private ObservableCollection<TimeSheet> _DataCollection;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the Selected Customer
    /// </summary>
    public Customer SelectedCustomer
    {
      get { return _SelectedCustomer; }
      set
      {
        _SelectedCustomer = value;
        RaisePropertyChanged("SelectedCustomer");
      }
    }

    /// <summary>
    /// Get/Set the collection of time sheet objects
    /// </summary>
    public ObservableCollection<TimeSheet> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region GetAllTimeSheets Method
    public void GetAllTimeSheets()
    {
      TimeSheetServicesClient client = new TimeSheetServicesClient();

      // Reset View Model Variables
      IsNoRecordsVisible = false;
      IsMessageVisible = true;
      MessageToDisplay = "Loading Time Sheets...";

      client.GetAllTimeSheetsCompleted += new System.EventHandler<GetAllTimeSheetsCompletedEventArgs>(client_GetAllTimeSheetsCompleted);
      client.GetAllTimeSheetsAsync();
      client.CloseAsync();
    }

    void client_GetAllTimeSheetsCompleted(object sender, GetAllTimeSheetsCompletedEventArgs e)
    {
      TimeSheetResponse ret;

      ret = (TimeSheetResponse)e.Result;
      if (ret.Status == OperationResult.Success)
      {
        DataCollection = ret.DataCollection;
        IsMessageVisible = false;
      }
      else if (ret.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No time sheets found.";
        IsNoRecordsVisible = true;
      }
    }
    #endregion

    #region GetTimeSheetsByCustomer Method
    public void GetTimeSheetsByCustomer(Customer entity)
    {
      TimeSheetServicesClient client = new TimeSheetServicesClient();

      // Reset View Model Variables
      IsNoRecordsVisible = false;
      IsMessageVisible = true;
      MessageToDisplay = "Loading Customer Time Sheets...";

      client.GetTimeSheetsByCustomerCompleted += new System.EventHandler<GetTimeSheetsByCustomerCompletedEventArgs>(client_GetTimeSheetsByCustomerCompleted);
      client.GetTimeSheetsByCustomerAsync(entity);
      client.CloseAsync();
    }

    void client_GetTimeSheetsByCustomerCompleted(object sender, GetTimeSheetsByCustomerCompletedEventArgs e)
    {
      TimeSheetResponse ret;

      ret = (TimeSheetResponse)e.Result;
      if (ret.Status == OperationResult.Success)
      {
        DataCollection = ret.DataCollection;
        IsMessageVisible = false;
      }
      else if (ret.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No customer time sheets found.";
        IsNoRecordsVisible = true;
      }
    }
    #endregion
  }
}
