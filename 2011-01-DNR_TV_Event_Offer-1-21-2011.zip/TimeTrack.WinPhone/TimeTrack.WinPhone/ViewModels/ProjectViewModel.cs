﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common.Library;
using TimeTrack.EntityClasses;
using TimeTrack.WinPhone.ProjectServiceReference;

namespace TimeTrack.WinPhone
{
  public class ProjectViewModel : ViewModelBase
  {
    public ProjectViewModel()
    {
      MessageToDisplay = "Please wait while loading projects...";
    }

    #region Private Variables
    private ObservableCollection<Project> _DataCollection;
    private IEnumerable<Project> _FilteredDataCollection;
    #endregion

    #region Public Properties
    public ObservableCollection<Project> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public IEnumerable<Project> FilteredDataCollection
    {
      get { return _FilteredDataCollection; }
      set
      {
        _FilteredDataCollection = value;
        RaisePropertyChanged("FilteredDataCollection");
      }
    }
    #endregion

    #region GetProjectsByCustomers Method
    public void GetProjectsByCustomers(Customer entity)
    {
      ProjectServicesClient client = new ProjectServicesClient();

      // Reset View Model Variables
      IsNoRecordsVisible = false;
 
      client.GetProjectsByCustomerCompleted += new EventHandler<GetProjectsByCustomerCompletedEventArgs>(client_GetProjectsByCustomerCompleted);
      client.GetProjectsByCustomerAsync(entity);
      client.CloseAsync();
    }

    void client_GetProjectsByCustomerCompleted(object sender, GetProjectsByCustomerCompletedEventArgs e)
    {
      ProjectResponse ret;

      ret = (ProjectResponse)e.Result;
      if (ret.Status == OperationResult.Success)
      {
        DataCollection = ret.DataCollection;
        FilteredDataCollection = DataCollection;
        IsMessageVisible = false;
      }
      else if (ret.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No projects found for customer.";
        IsNoRecordsVisible = true;
      }
    }
    #endregion

    #region FilterProjects Method
    public void FilterProjects(string filter)
    {
      FilteredDataCollection =
        from proj in DataCollection
        where proj.ProjectName.ToLower().StartsWith(filter.ToLower())
        orderby proj.ProjectName
        select proj;
    }
    #endregion
  }
}
