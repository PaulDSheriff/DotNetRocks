﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common.Library;
using TimeTrack.EntityClasses;
using TimeTrack.WinPhone.EmployeeServiceReference;

namespace TimeTrack.WinPhone
{
  public class EmployeeViewModel : ViewModelBase
  {
    public EmployeeViewModel()
    {
      MessageToDisplay = "Please wait while loading employees...";
    }

    #region Private Variables
    private ObservableCollection<Employee> _DataCollection;
    private IEnumerable<Employee> _FilteredDataCollection;
    #endregion

    #region Public Properties
    public ObservableCollection<Employee> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public IEnumerable<Employee> FilteredDataCollection
    {
      get { return _FilteredDataCollection; }
      set
      {
        _FilteredDataCollection = value;
        RaisePropertyChanged("FilteredDataCollection");
      }
    }
    #endregion

    #region GetEmployees Method
    public void GetEmployees()
    {
      EmployeeServicesClient client = new EmployeeServicesClient();

      // Reset View Model Variables
      IsNoRecordsVisible = false;

      client.GetEmployeesCompleted += new EventHandler<GetEmployeesCompletedEventArgs>(client_GetEmployeesCompleted);
      client.GetEmployeesAsync();
      client.CloseAsync();
    }

    void client_GetEmployeesCompleted(object sender, GetEmployeesCompletedEventArgs e)
    {
      EmployeeResponse ret;

      ret = (EmployeeResponse)e.Result;
      if (ret.Status == OperationResult.Success)
      {
        DataCollection = ret.DataCollection;
        FilteredDataCollection = DataCollection;
        IsMessageVisible = false;
      }
      else if (ret.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No Employees found.";
        IsNoRecordsVisible = true;
      }
    }
    #endregion

    #region FilterEmployees Method
    public void FilterEmployees(string filter)
    {
      FilteredDataCollection =
        from Employee in DataCollection
        where Employee.LastName.ToLower().StartsWith(filter.ToLower())
        orderby Employee.LastName
        select Employee;
    }
    #endregion
  }
}
