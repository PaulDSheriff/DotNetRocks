﻿using System;
using System.Data;
using Common.Library;
using TimeTrack.EntityClasses;

namespace TimeTrack.DataClasses
{
  /// <summary>
  /// Class to read/write time sheet data
  /// </summary>
  public partial class TimeSheetData : DataClassBase
  {
    #region Public Properties
    /// <summary>
    /// Get/Set a TimeSheet Entity Object
    /// </summary>
    public TimeSheet Entity { get; set; }
    #endregion

    #region GetTimeSheet Method
    /// <summary>
    /// Get a Time Sheet object
    /// </summary>
    /// <param name="entity">A timesheet entity with the TimeSheetId filled in</param>
    /// <returns>A TimeSheet object</returns>
    public TimeSheet GetTimeSheet(TimeSheet entity)
    {
      TimeSheet ret = new TimeSheet();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT dbo.TimeSheet.TimeSheetId, dbo.TimeSheet.ProjectId, ProjectName, dbo.TimeSheet.CustomerId, CustomerName, dbo.TimeSheet.EmployeeId As EmployeeId, LastName + ', ' + FirstName As EmployeeName, TaskDate, Description, Hours ";
      SQL += " FROM dbo.TimeSheet ";
      SQL += " INNER JOIN dbo.Customer on dbo.TimeSheet.CustomerId = dbo.Customer.CustomerId ";
      SQL += " INNER JOIN dbo.Project on dbo.TimeSheet.ProjectId = dbo.Project.ProjectId ";
      SQL += " INNER JOIN dbo.Employee on dbo.TimeSheet.EmployeeId = dbo.Employee.EmployeeId ";
      SQL += " WHERE TimeSheetId = @TimeSheetId ";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@TimeSheetId", entity.TimeSheetId));
      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        if (dt.Rows.Count > 0)
          ret = DataRowToEntity(dt.Rows[0]);
      }

      return ret;
    }
    #endregion

    #region GetAllTimeSheets Method
    /// <summary>
    /// Get All Time Sheet objects for all customers
    /// </summary>
    /// <returns>A collection of Time Sheet objects</returns>
    public TimeSheets GetAllTimeSheets()
    {
      return GetTimeSheets(null);
    }
    #endregion

    #region GetTimeSheetsByCustomer Method
    /// <summary>
    /// Get All Time Sheet objects for a specific customer
    /// </summary>
    /// <param name="entity">A Customer object with the CustomerId property filled in, or a null to get all customers</param>
    /// <returns>A collection of Time Sheet objects</returns>
    public TimeSheets GetTimeSheetsByCustomer(Customer entity)
    {
      return GetTimeSheets(entity);
    }
    #endregion

    #region GetTimeSheets Method
    /// <summary>
    /// Get All Time Sheet objects for a specific customer
    /// </summary>
    /// <param name="entity">A Customer object with the CustomerId property filled in, or a null to get all customers</param>
    /// <returns>A collection of Time Sheet objects</returns>
    protected TimeSheets GetTimeSheets(Customer entity)
    {
      TimeSheets ret = new TimeSheets();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT dbo.TimeSheet.TimeSheetId, dbo.TimeSheet.ProjectId, ProjectName, dbo.TimeSheet.CustomerId, CustomerName, dbo.TimeSheet.EmployeeId As EmployeeId, LastName + ', ' + FirstName As EmployeeName, TaskDate, Description, Hours ";
      SQL += " FROM dbo.TimeSheet ";
      SQL += " INNER JOIN dbo.Customer on dbo.TimeSheet.CustomerId = dbo.Customer.CustomerId ";
      SQL += " INNER JOIN dbo.Project on dbo.TimeSheet.ProjectId = dbo.Project.ProjectId ";
      SQL += " INNER JOIN dbo.Employee on dbo.TimeSheet.EmployeeId = dbo.Employee.EmployeeId ";
      if (entity != null)
        SQL += " WHERE dbo.TimeSheet.CustomerId = @CustomerId ";
      SQL += " ORDER BY dbo.TimeSheet.CustomerId, dbo.TimeSheet.ProjectId, TaskDate ";

      CommandObject = DataLayer.CreateCommand(SQL);

      if (entity != null)
      {
        CommandObject.Parameters.Clear();
        CommandObject.Parameters.Add(DataLayer.CreateParameter("@CustomerId", entity.CustomerId));
      }

      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        foreach (DataRow dr in dt.Rows)
        {
          ret.Add(DataRowToEntity(dr));
        }
      }

      return ret;
    }
    #endregion

    #region DataRowToEntity Method
    /// <summary>
    /// Takes a DataRow object and moves all values into a new TimeSheet object
    /// </summary>
    /// <param name="dr">A DataRow object</param>
    /// <returns>A TimeSheet object</returns>
    public TimeSheet DataRowToEntity(DataRow dr)
    {
      TimeSheet ret = new TimeSheet();

      ret.TimeSheetId = Convert.ToInt32(dr["TimeSheetId"]);
      ret.CustomerId = Convert.ToInt32(dr["CustomerId"]);
      ret.Description = dr["Description"].ToString();
      ret.Hours = Convert.ToDecimal(dr["Hours"]);
      ret.ProjectId = Convert.ToInt32(dr["ProjectId"]);
      ret.TaskDate = Convert.ToDateTime(dr["TaskDate"]);
      ret.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);

      ret.CustomerName = dr["CustomerName"].ToString();
      ret.ProjectName = dr["ProjectName"].ToString();
      ret.EmployeeName = dr["EmployeeName"].ToString();

      return ret;
    }
    #endregion

    #region Insert Method
    public int Insert(TimeSheet entity)
    {
      RowsAffected = 0;
      SQL = "INSERT INTO dbo.TimeSheet (ProjectId, CustomerId, EmployeeId, TaskDate, Description, Hours ) VALUES ( @ProjectId, @CustomerId, @EmployeeId, @TaskDate, @Description, @Hours )";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Clear();
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@ProjectId", entity.ProjectId));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@CustomerId", entity.CustomerId));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@EmployeeId", entity.EmployeeId));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@TaskDate", entity.TaskDate));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@Description", entity.Description));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@Hours", entity.Hours));

      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      RowsAffected = DataLayer.ExecuteSQL(CommandObject);

      return RowsAffected;
    }
    #endregion

    #region Update Method
    public int Update(TimeSheet entity)
    {
      RowsAffected = 0;
      SQL = "UPDATE dbo.TimeSheet SET ProjectId = @ProjectId, CustomerId = @CustomerId, EmployeeId = @EmployeeId, TaskDate = @TaskDate, Description = @Description, Hours = @Hours WHERE TimeSheetId = @TimeSheetId";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Clear();
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@ProjectId", entity.ProjectId));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@CustomerId", entity.CustomerId));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@EmployeeId", entity.EmployeeId));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@TaskDate", entity.TaskDate));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@Description", entity.Description));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@Hours", entity.Hours));
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@TimeSheetId", entity.TimeSheetId));

      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      RowsAffected = DataLayer.ExecuteSQL(CommandObject);

      return RowsAffected;
    }
    #endregion

    #region DeleteByPK Method
    public int DeleteByPK(TimeSheet entity)
    {
      RowsAffected = 0;
      SQL = "DELETE FROM dbo.TimeSheet WHERE TimeSheetId = @TimeSheetId";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Clear();
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@TimeSheetId", entity.TimeSheetId));

      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      RowsAffected = DataLayer.ExecuteSQL(CommandObject);

      return RowsAffected;
    }
    #endregion
  }
}
