﻿using System;
using System.Data;
using Common.Library;
using TimeTrack.EntityClasses;

namespace TimeTrack.DataClasses
{
  /// <summary>
  /// Class to read/write project data
  /// </summary>
  public partial class ProjectData : DataClassBase
  {
    #region Public Properties
    public Project Entity { get; set; }
    #endregion

    #region GetProject Method
    public Project GetProject(Project entity)
    {
      Project ret = new Project();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT ProjectId, CustomerId, ProjectName, EstimatedHours FROM dbo.Project WHERE ProjectId = @ProjectId";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@ProjectId", entity.ProjectId));
      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        if (dt.Rows.Count > 0)
          ret = DataRowToEntity(dt.Rows[0]);
      }

      return ret;
    }
    #endregion

    #region GetProjectsByCustomer
    public Projects GetProjectsByCustomer(int customerId)
    {
      Projects ret = new Projects();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT ProjectId, CustomerId, ProjectName, EstimatedHours FROM dbo.Project WHERE CustomerId = @CustomerId ORDER BY ProjectName";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Clear();
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@CustomerId", customerId));
      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        foreach (DataRow dr in dt.Rows)
        {
          ret.Add(DataRowToEntity(dr));
        }
      }

      return ret;
    }
    #endregion

    #region DataRowToEntity Method
    public Project DataRowToEntity(DataRow dr)
    {
      Project ret = new Project();

      ret.CustomerId = Convert.ToInt32(dr["CustomerId"]);
      ret.EstimatedHours = Convert.ToDecimal(dr["EstimatedHours"]);
      ret.ProjectId = Convert.ToInt32(dr["ProjectId"]);
      ret.ProjectName = dr["ProjectName"].ToString();

      return ret;
    }
    #endregion
  }
}
