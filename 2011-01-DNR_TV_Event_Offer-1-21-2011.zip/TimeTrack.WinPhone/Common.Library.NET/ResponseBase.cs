﻿using System;
using System.Runtime.Serialization;

namespace Common.Library
{
  #region OperationResult Enumeration
  /// <summary>
  /// Enumeration for the results of calls to data services
  /// </summary>
  public enum OperationResult
  {
    Unknown,
    Success,
    Exception,
    Failure,
    NoRecords,
    ValidationFailed
  }
  #endregion

  /// <summary>
  /// Class that all Response objects will inherit from
  /// </summary>
  [DataContract]
  public class ResponseBase
  {
    #region Constructor
    public ResponseBase()
    {
      Status = OperationResult.Unknown;
      FriendlyErrorMessage = string.Empty;
      ErrorMessage = string.Empty;
    }
    #endregion

    #region Public Properties
    [DataMember]
    public OperationResult Status { get; set; }

    [DataMember]
    public string FriendlyErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessageExtended { get; set; }

    [DataMember]
    public int RowsAffected { get; set; }
    #endregion
  }
}
