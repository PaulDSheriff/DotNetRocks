﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace Common.Library
{
  /// <summary>
  /// Class for Common Windows Phone Functionality
  /// </summary>
  public class WinPhoneCommon
  {
    /// <summary>
    /// Returns the Application Title from the WMAppManifest.xml file
    /// </summary>
    /// <returns>The application title</returns>
    public static string GetApplicationTitle()
    {
      return GetWinPhoneAttribute("Title");
    }

    /// <summary>
    /// Returns the Application Description from the WMAppManifest.xml file
    /// </summary>
    /// <returns>The application description</returns>
    public static string GetApplicationDescription()
    {
      return GetWinPhoneAttribute("Description");
    }

    #region GetWinPhoneAttribute Method

    /// <summary>
    /// Gets an attribute from the Windows Phone WMAppManifest.xml file
    /// To use this method, add a reference to the System.Xml.Linq DLL
    /// </summary>
    /// <param name="attributeName">The attribute to read</param>
    /// <returns>The Attribute's Value</returns>
    private static string GetWinPhoneAttribute(string attributeName)
    {
      string ret = string.Empty;

      try
      {
        XElement xe = XElement.Load("WMAppManifest.xml");
        var attr = (from manifest in xe.Descendants("App")
                    select manifest).SingleOrDefault();
        if (attr != null)
          ret = attr.Attribute(attributeName).Value;
      }
      catch
      {
        // Ignore errors in case this method is called 
        // from design time in VS.NET
      }

      return ret;
    }
    #endregion
  }
}
