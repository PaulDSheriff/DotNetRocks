using System.Runtime.Serialization;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class for sending data back to the client about the result of calling the WCF service
  /// </summary>
  [DataContract]
  public class ProjectResponse : ResponseBase
  {
    [DataMember]
    public Project DetailData { get; set; }

    [DataMember]
    public Projects DataCollection { get; set; }
  }
}

