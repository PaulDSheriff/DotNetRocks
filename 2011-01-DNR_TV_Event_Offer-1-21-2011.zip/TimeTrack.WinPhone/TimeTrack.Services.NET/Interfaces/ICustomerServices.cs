using System.ServiceModel;

using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  [ServiceContract(Namespace = "http://TimeTrack.Services")]
  public interface ICustomerServices
  {
    [OperationContract]
    CustomerResponse GetCustomer(Customer entity);

    [OperationContract]
    CustomerResponse GetCustomers();
  }
}
