using System;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class connected to by the WCF Service (.svc) to perform data services
  /// </summary>
  public partial class EmployeeServices : IEmployeeServices
  {
    #region CreateEmployeeDataObject Method
    private EmployeeData CreateEmployeeDataObject()
    {
      EmployeeData ret = new EmployeeData();

      ret.ConnectString = ret.GetConnectString("TimeTrack");

      return ret;
    }
    #endregion
    
    #region GetEmployee Method
    public EmployeeResponse GetEmployee(Employee entity)
    {
      EmployeeResponse ret = new EmployeeResponse();
      EmployeeData data = null;           

      try
      {
        data = CreateEmployeeDataObject();

        ret.DetailData = data.GetEmployee(entity);
        ret.RowsAffected = data.RowsAffected;
          ret.Status = OperationResult.Success;
        if(ret.RowsAffected == 0)
        {
          ret.Status = OperationResult.NoRecords;
          ret.FriendlyErrorMessage = "The record you were looking for was not found.";
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region GetEmployees Method
    public EmployeeResponse GetEmployees()
    {
      EmployeeResponse ret = new EmployeeResponse();
      EmployeeData data = null;
      
      try
      {
        data = CreateEmployeeDataObject();

        ret.DataCollection = data.BuildCollection();
        ret.RowsAffected = data.RowsAffected;
        if (ret.DataCollection != null)
        {
          if (ret.DataCollection.Count > 0)
            ret.Status = OperationResult.Success;
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "No records were found for this table.";
          }
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

  }
}

