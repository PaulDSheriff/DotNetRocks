using System;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class connected to by the WCF Service (.svc) to perform data services
  /// </summary>
  public partial class TimeSheetServices : ITimeSheetServices
  {
    #region CreateTimeSheetDataObject Method
    private TimeSheetData CreateTimeSheetDataObject()
    {
      TimeSheetData ret = new TimeSheetData();

      ret.ConnectString = ret.GetConnectString("TimeTrack");

      return ret;
    }
    #endregion

    #region GetTimeSheet Method
    public TimeSheetResponse GetTimeSheet(TimeSheet entity)
    {
      TimeSheetResponse ret = new TimeSheetResponse();
      TimeSheetData data = null;

      try
      {
        data = CreateTimeSheetDataObject();

        ret.DetailData = data.GetTimeSheet(entity);
        ret.RowsAffected = data.RowsAffected;
        ret.Status = OperationResult.Success;
        if (ret.RowsAffected == 0)
        {
          ret.Status = OperationResult.NoRecords;
          ret.FriendlyErrorMessage = "The record you were looking for was not found.";
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region GetAllTimeSheets Method
    public TimeSheetResponse GetAllTimeSheets()
    {
      return GetTimeSheets(null);
    }
    #endregion

    #region GetTimeSheetsByCustomer Method
    public TimeSheetResponse GetTimeSheetsByCustomer(Customer entity)
    {
      return GetTimeSheets(entity);
    }
    #endregion

    #region GetTimeSheets Method
    /// <summary>
    /// Returns all time sheets if you pass a Null into the entity parameter. Otherwise returns time sheets just for that customer
    /// </summary>
    /// <param name="entity">A customer entity object, or a null</param>
    /// <returns>A collection of Time Sheet objects</returns>
    protected TimeSheetResponse GetTimeSheets(Customer entity)
    {
      TimeSheetResponse ret = new TimeSheetResponse();
      TimeSheetData data = null;

      try
      {
        data = CreateTimeSheetDataObject();

        if (entity == null)
          ret.DataCollection = data.GetAllTimeSheets();
        else
          ret.DataCollection = data.GetTimeSheetsByCustomer(entity);

        ret.RowsAffected = data.RowsAffected;
        if (ret.DataCollection != null)
        {
          if (ret.DataCollection.Count > 0)
            ret.Status = OperationResult.Success;
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "No records were found for this table.";
          }
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region Insert Method
    public TimeSheetResponse Insert(TimeSheet entity)
    {
      TimeSheetResponse ret = new TimeSheetResponse();
      TimeSheetData data = null;

      try
      {
        data = CreateTimeSheetDataObject();

        ret.RowsAffected = data.Insert(entity);
        if (ret.RowsAffected > 0)
        {
          // In case any data changed
          ret.DetailData = data.Entity;
          ret.Status = OperationResult.Success;
        }
        else
        {
          ret.Status = OperationResult.NoRecords;
          ret.FriendlyErrorMessage = "No Records Were Inserted.";
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion
  }
}

