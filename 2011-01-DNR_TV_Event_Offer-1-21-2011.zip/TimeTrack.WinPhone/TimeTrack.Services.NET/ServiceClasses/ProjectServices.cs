using System;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class connected to by the WCF Service (.svc) to perform data services
  /// </summary>
  public partial class ProjectServices : IProjectServices
  {
    #region CreateProjectDataObject Method
    private ProjectData CreateProjectDataObject()
    {
      ProjectData ret = new ProjectData();

      ret.ConnectString = ret.GetConnectString("TimeTrack");

      return ret;
    }
    #endregion
    
    #region GetProject Method
    public ProjectResponse GetProject(Project entity)
    {
      ProjectResponse ret = new ProjectResponse();
      ProjectData data = null;

      try
      {
        data = CreateProjectDataObject();

        ret.DetailData = data.GetProject(entity);
        ret.RowsAffected = data.RowsAffected;
        ret.Status = OperationResult.Success;
        if(ret.RowsAffected == 0)
        {
          ret.Status = OperationResult.NoRecords;
          ret.FriendlyErrorMessage = "The record you were looking for was not found.";
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

    #region GetProjectsByCustomer Method
    public ProjectResponse GetProjectsByCustomer(Customer entity)
    {
      ProjectResponse ret = new ProjectResponse();
      ProjectData data = null;

      try
      {
        data = CreateProjectDataObject();
        
        // For testing only
        if (entity == null)
        {
          entity = new Customer();
          entity.CustomerId = 1;
        }
        else if (entity.CustomerId == 0)
          entity.CustomerId = 1;

        ret.DataCollection = data.GetProjectsByCustomer(entity.CustomerId);
        ret.RowsAffected = data.RowsAffected;
        if (ret.DataCollection != null)
        {
          if (ret.DataCollection.Count > 0)
            ret.Status = OperationResult.Success;
          else
          {
            ret.Status = OperationResult.NoRecords;
            ret.FriendlyErrorMessage = "No records were found for this table.";
          }
        }
      }
      catch (Exception ex)
      {
        ret.ErrorMessage = ex.Message;
        ret.ErrorMessageExtended = ex.ToString();
        ret.Status = OperationResult.Exception;
      }

      return ret;
    }
    #endregion

  }
}

